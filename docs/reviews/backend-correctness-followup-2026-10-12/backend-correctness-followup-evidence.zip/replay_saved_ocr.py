"""Replay exact adapter functions over saved model outputs, without model inference."""
import argparse
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
cli = argparse.ArgumentParser()
cli.add_argument("--repo", type=Path, required=True)
cli.add_argument("--traces", type=Path, required=True)
cli.add_argument("--out", type=Path, required=True)
args = cli.parse_args()
sys.path.insert(0, str(args.repo / "backend"))
from app.pipeline.paddle_reader import _table_lines, _check_descriptions, _replace_table
from app.pipeline.rows import parse_line_items
from app.pipeline.extract import extract_fields
from app.pipeline.classify import classify

lines = (args.traces / "ordinary-1-0.txt").read_text(encoding="utf-8").splitlines()
html = (args.traces / "structure-1-0.md").read_text(encoding="utf-8")
table = _table_lines(html)
table, uncertain, corrections = _check_descriptions(table, lines)
reconstructed = _replace_table(lines, table)
parsed = parse_line_items(reconstructed, page=1)
fields = extract_fields(parsed.doc_text, classify(reconstructed, "commercial_invoice.scan.png"), page=1, row_keys=parsed.header_keys)
result = {"model_called": False, "source": "saved exact ordinary/structure outputs for SHP-00001 commercial_invoice.scan.png",
          "fields": fields, "line_items": parsed.line_items, "uncertain_codes": uncertain,
          "corrections": corrections, "reconstructed_text": reconstructed}
args.out.write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
print(json.dumps({"shipper": next(f for f in fields if f['field_key']=='shipper'),
                  "consignee": next(f for f in fields if f['field_key']=='consignee'), "uncertain_codes": uncertain}, ensure_ascii=False))
