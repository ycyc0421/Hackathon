"""Independent incremental acceptance on the pinned candidate, with real TCP HTTP.

No production mutations, author script execution, model downloads, or source edits.
Only processes created here are ever terminated. Expected values stay in this client.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import socket
import sqlite3
import subprocess
import sys
import time

import httpx

ROOT = Path(__file__).resolve().parent
PIN = '1c5924338e21caaed0f5ea5c76a33048bbce98dc'
OLD = ROOT/'old-materials'
DATA = OLD/'inputs/dataset'
OUT = ROOT/'evidence'
CREATION = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
CHILD_ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for key in ['LLM_API_KEY', 'LLM_BASE_URL', 'LLM_MODEL', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN']:
    CHILD_ENV.pop(key, None)

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

def stop_owned(process):
    if process is not None and process.poll() is None:
        process.kill()
        process.wait(timeout=15)

class Server:
    def __init__(self, output, mode='text', rec_url=''):
        self.output, self.mode = output, mode
        self.runtime = output/'runtime'
        self.port = port()
        output.mkdir(parents=True, exist_ok=True)
        self.log = (output/f'server-{mode}-{time.time_ns()}.log').open('wb')
        command = [sys.executable, '-X', 'utf8', str(ROOT/'serve_review.py'), '--runtime', str(self.runtime),
                   '--port', str(self.port), '--mode', mode, '--rec-url', rec_url]
        self.process = subprocess.Popen(command, cwd=ROOT/'candidate', env=CHILD_ENV, stdout=self.log,
                                        stderr=subprocess.STDOUT, creationflags=CREATION)
        self.client = httpx.Client(base_url=f'http://127.0.0.1:{self.port}', timeout=30, trust_env=False)
        for _ in range(300):
            if self.process.poll() is not None: raise RuntimeError('isolated server exited; inspect log')
            try:
                health = self.client.get('/health')
                if health.status_code == 200:
                    save(output/f'health-{mode}.json', health.json())
                    save(output/f'process-{mode}.json', {'pid': self.process.pid, 'command': command, 'owned_by_this_driver': True})
                    return
            except httpx.HTTPError: pass
            time.sleep(.1)
        self.close()
        raise TimeoutError('isolated server startup')
    def close(self):
        stop_owned(self.process)
        self.client.close()
        self.log.close()
    def upload(self, case, paths, country='US', wait=True):
        originals = [{'file_name':path.name, 'path':str(path), 'sha256':digest(path), 'bytes':path.stat().st_size} for path in paths]
        files = [('files',(path.name,path.read_bytes(),'application/pdf' if path.suffix == '.pdf' else 'image/png')) for path in paths]
        response = self.client.post('/api/v1/checks', data={'destination_country':country}, files=files)
        value = response.json()
        save(self.output/'requests'/f'{case}.json', {'method':'POST','base_url':str(self.client.base_url), 'path':'/api/v1/checks',
                                                  'data':{'destination_country':country}, 'files':originals,
                                                  'http_status':response.status_code,'response':value})
        response.raise_for_status()
        task_id = value['task_id']
        polls=[]
        deadline=time.monotonic()+600
        while wait and value['status'] in {'PENDING','PROCESSING'}:
            if time.monotonic()>deadline: raise TimeoutError(case)
            time.sleep(.2)
            value=self.get(task_id)
            polls.append({'time':time.time(),'status':value['status'],'documents':value['documents']})
        save(self.output/'polls'/f'{case}.json',polls)
        save(self.output/'public'/f'{case}.json',value)
        return value
    def get(self, task_id):
        r=self.client.get(f'/api/v1/checks/{task_id}');r.raise_for_status();return r.json()
    def report(self, case, task_id):
        r=self.client.get(f'/api/v1/checks/{task_id}/report?format=json')
        r.raise_for_status();save(self.output/'reports'/f'{case}.json',r.json())
    def download(self, task_id, file_id, original):
        r=self.client.get(f'/api/v1/checks/{task_id}/files/{file_id}')
        return {'file_id':file_id,'http_status':r.status_code,'expected_sha256':digest(original),
                'actual_sha256':hashlib.sha256(r.content).hexdigest(),'passed':r.status_code==200 and r.content==original.read_bytes()}

def country_review():
    output=OUT/'country'
    before=json.loads((OLD/'evidence/digital/destination-country-checks.json').read_text(encoding='utf-8'))
    failures=[x for x in before if not x['passed']]
    groups=sorted({x['case'] for x in failures})
    assert len(groups)==42 and len(failures)==126
    hashes=json.loads((DATA/'input_sha256.json').read_text(encoding='utf-8'))
    checks=[]
    server=Server(output)
    try:
        for n,group in enumerate(groups,1):
            expected=[x for x in failures if x['case']==group]
            paths=[DATA/'backend/samples'/group/x['file'] for x in expected]
            for path in paths: assert digest(path)==hashes[path.relative_to(DATA).as_posix()]
            # Intentionally request US while the documents say AU/SG; expected answers are not sent to the API.
            task=server.upload(group,paths,country='US')
            server.report(group,task['task_id'])
            for old in expected:
                doc=next(d for d in task['documents'] if d['file_name']==old['file'])
                ext=next(e for e in task['extractions'] if e['file_id']==doc['file_id'])
                field=next(f for f in ext['fields'] if f['field_key']=='destination_country' and f.get('line_no') is None)
                checks.append({'case':group,'file':old['file'],'old_status':old['status'],'old_raw_value':old['raw_value'],
                               'expected':old['expected'],'field':field,'document_status':doc['process_status'],
                               'input_country':'US','passed':field['normalized_value']==old['expected'] and field['status']=='EXTRACTED'
                               and field['raw_value']==old['raw_value'] and doc['process_status']=='EXTRACTED'})
            if n%10==0: print(f'COUNTRY {n}/{len(groups)}',flush=True)
    finally: server.close()
    save(output/'checks.json',checks)
    summary={'source_commit':PIN,'scope':'Only all 42 previously failed AU/SG groups; real old PDFs and real TCP HTTP',
             'groups':len(groups),'fields':len(checks),'passed':sum(x['passed'] for x in checks),
             'failed':[x for x in checks if not x['passed']], 'raw_forms':dict(Counter(x['field']['raw_value'] for x in checks))}
    save(output/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)

def internal_snapshot(runtime):
    with sqlite3.connect(f'file:{(runtime/"tasks.sqlite3").as_posix()}?mode=ro',uri=True) as conn:
        return [json.loads(row[0]) for row in conn.execute('SELECT payload_json FROM api_task_payloads ORDER BY task_id')]

def interruption_round(label, partial=False):
    output=OUT/'interruption'/label
    scanroot=DATA/'backend/samples/SHP-00001'
    paths=[scanroot/x for x in ['commercial_invoice.scan.png','packing_list.scan.png','proforma_invoice.scan.png']]
    if partial: paths[0]=scanroot/'commercial_invoice.pdf'
    server=Server(output,'partial-gate' if partial else 'gate')
    tasks=[];checks=[]
    try:
        for n in range(1 if partial else 4):
            task=server.upload(f'accepted-{n+1}',paths,wait=False)
            tasks.append(task['task_id'])
        for _ in range(100):
            if list(server.runtime.glob('gate-*.json')): break
            time.sleep(.1)
        markers=[json.loads(p.read_text()) for p in server.runtime.glob('gate-*.json')]
        assert markers, 'did not reach processing gate'
        save(output/'gate-markers.json',markers)
        before=internal_snapshot(server.runtime);save(output/'before-internal.json',before)
        for task_id in tasks:
            task=server.get(task_id);save(output/'before-public'/f'{task_id}.json',task)
            checks.append({'check':f'{task_id} complete accepted list before inference','passed':len(task['documents'])==3 and task['summary']['document_count']==3})
            for n,path in enumerate(paths,1):
                source=server.runtime/'uploads'/task_id/f'f{n}.source'
                checks.append({'check':f'{task_id}/f{n} durable before inference','passed':source.exists() and digest(source)==digest(path)})
            if partial:
                checks.append({'check':'first real text PDF completed before crash','passed':task['documents'][0]['process_status']=='EXTRACTED'})
        if not partial:
            r=server.client.post('/api/v1/checks',data={'destination_country':'US'},files=[('files',(p.name,p.read_bytes(),'image/png')) for p in paths])
            save(output/'fifth-request.json',{'http_status':r.status_code,'response':r.json()})
            checks.append({'check':'fifth active/queued task rejected','passed':r.status_code==429 and r.json()['error']['code']=='CHECK_QUEUE_FULL'})
        killed_pid=server.process.pid
        server.close()  # Windows TerminateProcess via Popen.kill, only this newly created API.
        save(output/'killed-process.json',{'pid':killed_pid,'action':'Popen.kill / Windows TerminateProcess','owned_process':True,
                                          'gate':'test-only pause before reader inference; real accepted uploads and SQLite, no forged results'})
        server=Server(output,'text')
        for task_id in tasks:
            task=server.get(task_id);save(output/'after-public'/f'{task_id}.json',task)
            statuses=[d['process_status'] for d in task['documents']]
            checks.append({'check':f'{task_id} failed with interruption reason','passed':task['status']=='FAILED' and bool(task['finished_at'])
                           and any(e['code']=='TASK_INTERRUPTED' for e in task['errors'])})
            checks.append({'check':f'{task_id} all files finalized','passed':len(statuses)==3 and all(s not in {'UPLOADED','PARSING'} for s in statuses), 'states':statuses})
            if partial: checks.append({'check':'completed document retained after crash','passed':statuses==['EXTRACTED','FAILED','FAILED']})
            server.report(task_id,task_id)
            for n,path in enumerate(paths,1):
                check=server.download(task_id,f'f{n}',path);check['check']=f'{task_id}/f{n} original download after restart';checks.append(check)
        save(output/'after-internal.json',internal_snapshot(server.runtime))
    finally: server.close()
    save(output/'checks.json',checks)
    summary={'source_commit':PIN,'task_count':len(tasks),'original_count':len(tasks)*3,'checks':len(checks),
             'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']],
             'method':'New isolated loopback API, harness pauses reader, actual owned-process kill and restart; not production or real model crash'}
    save(output/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)

def ocr_review():
    output=OUT/'new-vl'
    output.mkdir(parents=True,exist_ok=True)
    engine=Path(r'LOCAL_PROJECT_ROOT\ocr-local\runtime\llama-b11560-vulkan\llama-server.exe')
    modelroot=Path(r'LOCAL_PROJECT_ROOT\ocr-local\models\PaddleOCR-VL-1.6')
    layout=Path(r'LOCAL_PROJECT_ROOT\ocr-local\paddlex-cache\official_models\PP-DocLayoutV3')
    author=json.loads((ROOT/'author-evidence/runtime.json').read_text())['official_models']
    modelhashes={name:digest(modelroot/name) for name in author['model_hashes']}
    layouthashes={name:digest(layout/name) for name in author['layout_hashes']}
    assert modelhashes==author['model_hashes'] and layouthashes==author['layout_hashes']
    shutil.copytree(layout,ROOT/'ocr-layout',dirs_exist_ok=True)
    devices=subprocess.check_output([str(engine),'--list-devices'],stderr=subprocess.STDOUT,text=True,env=CHILD_ENV)
    device=next(line.split(':')[0].strip() for line in devices.splitlines() if 'NVIDIA' in line)
    recport=port()
    command=[str(engine),'-m',str(modelroot/'PaddleOCR-VL-1.6-GGUF.gguf'),'--mmproj',str(modelroot/'PaddleOCR-VL-1.6-GGUF-mmproj.gguf'),
             '--host','127.0.0.1','--port',str(recport),'--device',device,'--mmproj-device',device,
             '-ngl','all','-c','8192','--parallel','1','--temp','0','--alias','paddleocr-vl-1.6','--no-warmup']
    version=subprocess.check_output([str(engine),'--version'],stderr=subprocess.STDOUT,text=True,env=CHILD_ENV).strip()
    save(output/'environment.json',{'source_commit':PIN,'python':sys.version,
             'packages':{x:importlib.metadata.version(x) for x in ['fastapi','uvicorn','httpx','paddleocr','paddlepaddle','paddlex']},
             'engine':version,'device':device,'model_hashes':modelhashes,'layout_hashes':layouthashes,
             'difference_from_author':'Windows llama b11560 NVIDIA Vulkan; author Linux b11429 CPU. Identical BF16 GGUF/projector/layout bytes.',
             'model_downloads':False,'external_paid_api':False,'output_replay':False})
    log=(output/'llama.log').open('wb')
    process=None;server=None
    start=time.monotonic()
    try:
        process=subprocess.Popen(command,env=CHILD_ENV,stdout=log,stderr=subprocess.STDOUT,creationflags=CREATION)
        save(output/'llama-process.json',{'pid':process.pid,'command':command,'owned_process':True})
        with httpx.Client(timeout=5,trust_env=False) as client:
            for _ in range(600):
                if process.poll() is not None:raise RuntimeError('owned llama server exited')
                try:
                    if client.get(f'http://127.0.0.1:{recport}/health').status_code==200:break
                except httpx.HTTPError:pass
                time.sleep(.1)
            else:raise TimeoutError('local llama startup')
        server=Server(output,'vl',f'http://127.0.0.1:{recport}/v1')
        path=OLD/'inputs/shirt-originals/exportdoc-packing-list-sample.pdf'
        assert digest(path)=='fc3cc01f3956b88f7cf7b855aeb11f27b16b50da45ebb9a4ed8afcd89ed8ba95'
        task=server.upload('SHIRT-PL-NEW-VL',[path])
        server.report('SHIRT-PL-NEW-VL',task['task_id'])
        fields=task['extractions'][0]['fields'] if task['extractions'] else []
        packages=[f for f in fields if f['field_key']=='packages' and f.get('line_no') is not None]
        checks=[{'check':'real original scan EXTRACTED via OCR','passed':task['documents'][0]['process_status']=='EXTRACTED'
                 and bool(task['extractions']) and task['extractions'][0].get('parse_method')=='OCR','document':task['documents'][0]},
                {'check':'PKGS 20 row retains count and unknown unit','passed':len(packages)==1 and packages[0]['normalized_value']==20
                 and packages[0]['unit'] is None,'fields':packages},
                {'check':'PL does not invent amount','passed':all(f['normalized_value'] is None for f in fields if f['field_key'] in {'total_amount','amount'})}]
        for key,expected in [('quantity',500),('net_weight',150),('gross_weight',170),('volume',1.68)]:
            candidates=[f for f in fields if f['field_key']==key and f.get('line_no') is not None]
            checks.append({'check':f'PL row {key}','passed':len(candidates)==1 and candidates[0]['normalized_value']==expected,'fields':candidates})
        source=server.runtime/'uploads'/task['task_id']/'f1_model-output.json'
        if source.exists():
            shutil.copy2(source,output/'new-raw-model-output.json')
            raw=json.loads(source.read_text(encoding='utf-8'))
            checks.append({'check':'fresh model output saved by unmodified runner','passed':bool(raw),'sha256':digest(source)})
        else:checks.append({'check':'fresh model output saved by unmodified runner','passed':False})
        checks.append(dict(server.download(task['task_id'],'f1',path),check='original bytes after new inference'))
        save(output/'checks.json',checks)
        summary={'source_commit':PIN,'originals':1,'fresh_inference':True,'seconds':round(time.monotonic()-start,2),
                 'task_status':task['status'],'checks':len(checks),'passed':sum(c['passed'] for c in checks),'failed':[c for c in checks if not c['passed']],
                 'errors':task['errors'],'method':'actual multipart scan PDF -> image -> PaddleOCRVL v1.6 -> local BF16 llama -> runner extraction; no replay'}
        save(output/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)
    except Exception as error:
        save(output/'blocked.json',{'error':str(error),'type':type(error).__name__,'seconds':round(time.monotonic()-start,2)})
        raise
    finally:
        if server:server.close()
        stop_owned(process);log.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['country','interrupt','ocr'])
    args=parser.parse_args()
    actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'candidate',text=True).strip()
    assert actual==PIN, actual
    print(json.dumps({'phase':args.phase,'source_commit':actual,'started':datetime.now(timezone.utc).isoformat()},ensure_ascii=False),flush=True)
    if args.phase=='country':country_review()
    elif args.phase=='interrupt':
        interruption_round('active-and-queued')
        interruption_round('partly-complete',partial=True)
    else:ocr_review()
