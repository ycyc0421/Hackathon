import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone
import httpx

root=Path(__file__).resolve().parent
repo=root/'candidate'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
data={'checked_at':datetime.now(timezone.utc).isoformat(),
      'head':git('rev-parse','HEAD'),'base':git('rev-parse','d223d7c'),
      'author_full_material':git('rev-parse','333a711'),'author_production':git('rev-parse','831e90f'),
      'old_material_publication':git('rev-parse','e2976003'),'old_backend_test':'fca14f56910333c4bac8c72cfd6428ffe2fb6f2a',
      'main_is_ancestor':subprocess.run(['git','merge-base','--is-ancestor','d223d7c','HEAD'],cwd=repo).returncode==0,
      '333a711_to_831e90f':git('diff','--name-status','333a711..831e90f'),
      '831e90f_to_head':git('diff','--name-status','831e90f..HEAD'),
      'backend_app_changes_since_material_run':git('diff','333a711..HEAD','--','backend/app'),
      'candidate_status':git('status','--porcelain'),
      'checkout_skills':git('ls-files','.agents/*','*AGENTS.md')}
blob=subprocess.check_output(['git','show','e2976003:docs/reviews/backend-independent-fca14f5-2026-10-12/review37-fca14f5-independent.zip'],cwd=repo)
data['old_zip_in_fetched_commit_sha256']=hashlib.sha256(blob).hexdigest()
try:
    with httpx.Client(timeout=20,trust_env=False,follow_redirects=False) as client:
        r=client.get('https://hackathon.ychome.net/health')
        data['production_health']={'url':str(r.url),'http_status':r.status_code,'response':r.json(),
                                   'method':'read-only GET, no credentials'}
except Exception as error:
    data['production_health']={'url':'https://hackathon.ychome.net/health','error':str(error)}
(root/'evidence/source-relationships.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(data,ensure_ascii=False,indent=2))
