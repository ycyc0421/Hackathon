# 复现与证据层级

本包为已有本机独立复验的脱敏发布副本；本次发布不新增验收。代码固定为PR37 `1c5924338e21caaed0f5ea5c76a33048bbce98dc`，材料固定为旧B发布 `e2976003e68a8f17208ee1e2fac6f46a8c7424ca`。仓库及下载入口：

- [PR37固定交付](https://github.com/ycyc0421/Hackathon/blob/bb40043fe402a77d49dd48c4f2b6e9b3301a5da9/docs/reviews/paddle-vl-server-2026-10-12/README.md)
- [旧B原件与独立证据包](https://github.com/ycyc0421/Hackathon/raw/e2976003e68a8f17208ee1e2fac6f46a8c7424ca/docs/reviews/backend-independent-fca14f5-2026-10-12/review37-fca14f5-independent.zip)

旧包SHA256 `04d959ba3f986824ccc43a18611ef8004cd86bd9e2d23583683183ebe48e258c`；F包SHA256 `a1bd76d9cf00f6c001e14c19c941d3637b2f3c71e8c410d811d62d0443d7701e`。先核验哈希和成员，不直接执行任何附带脚本。

`incremental_review.py` / `serve_review.py` 为本次新编写的客户端与隔离启动器；未修改F/C/D实现。它们复用了旧B的原件、预期、TCP HTTP／独立runtime的做法；旧驱动固定旧SHA且会机械跑全量，因此没有直接运行旧脚本或作者验收脚本。

当前机器Python：`LOCAL_PROJECT_ROOT\tmp\review37-env-20261012\Scripts\python.exe`。在本目录执行：

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
& 'LOCAL_PROJECT_ROOT\tmp\review37-env-20261012\Scripts\python.exe' -X utf8 incremental_review.py country
& 'LOCAL_PROJECT_ROOT\tmp\review37-env-20261012\Scripts\python.exe' -X utf8 incremental_review.py interrupt
& 'LOCAL_PROJECT_ROOT\tmp\review37-env-20261012\Scripts\python.exe' -X utf8 incremental_review.py ocr
```

为防止重复测试，已有本次结果时应先阅读证据。复跑应先将脚本复制到新的测试目录，再放置固定 `candidate/` 与解压的 `old-materials/`，避免启动器把旧runtime中的活动任务视作中断。驱动只绑定127.0.0.1随机空闲端口；仅停止自己创建并持有Popen句柄的进程。中断组为真实上传、真实SQLite和真实Windows TerminateProcess，不伪造保存结果；gate仅人为延长读入入口，部分完成组首个文本PDF真实解析。`live_interruption.py` 为额外真实VL正在推理时的API中断，独立于gate。

OCR复用本机已有 `LOCAL_PROJECT_ROOT\ocr-local\models\PaddleOCR-VL-1.6`、`runtime\llama-b11560-vulkan` 及 `paddlex-cache\official_models\PP-DocLayoutV3`；开始前校验模型与布局哈希。只复制130MB现成布局到本任务目录，不下载模型。模型服务别名 `paddleocr-vl-1.6`，一并发，温度0；本机NVIDIA为Vulkan1。跨机器需只调整这些本地路径／设备及Python位置，模型字节和被测提交不变。启动器清空LLM配置与常见API凭据变量，关闭HF在线获取，没有配置收费服务。

证据层级：

- `evidence/country`：本次真实42票HTTP及逐原文字段核对。
- `evidence/new-vl`：本次一份原扫描的新推理、完整公开返回／报告、原始模型输出、引擎日志、原件截图与环境。无保存输出重放。`initial-*`仅为验收脚本字段位置错误的初始评估，最终检查记录说明了修正。
- `evidence/interruption`：本次新建API的中断前后原始状态、文件哈希、下载、进程记录；runtime数据库仅留在本机，不打包。
- `evidence/boundary-checks.json`：12项纯归一边界及1项来自本次保存PL的比较重算；这个比较检查不是第二次新推理。
- `evidence/validation`：49份本次终态与128份作者保存返回的Schema／引用／计数校验；后者不可称为B独立复跑了125票或六扫描。
- `evidence/material-integrity.json`：两个固定包的成员哈希／CRC及旧嵌套清单差异。
- `evidence/source-relationships.json`：提交差异与只读production health；目录名为candidate导致本地health release_revision=null，实际被测SHA由git固定断言核对。

新证据压缩包只含选择的真实旧反例、保存返回、报告、原始模型输出、日志、核验脚本和清单；不含模型、缓存、运行数据库、凭据、生产配置或作者可能重启服务的脚本。

公开版中的 REVIEW_ROOT、LOCAL_PROJECT_ROOT、LOCAL_USER_HOME、NODE_EXE 是位置占位符，按复现机器配置替换；localhost随机端口、版本、原件及业务值不变。实际被测提交仍为 1c5924338e21caaed0f5ea5c76a33048bbce98dc，当前脱敏头 bb40043fe402a77d49dd48c4f2b6e9b3301a5da9 的相关代码blob一致；本包没有在新头重跑测试。F旧材料SHA是历史核验记录，当前F脱敏材料另以其清单为准。
