"""Test-only launcher. Runtime paths are isolated; candidate files are never edited."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import threading
import time

p = argparse.ArgumentParser()
p.add_argument('--runtime', type=Path, required=True)
p.add_argument('--port', type=int, required=True)
p.add_argument('--mode', choices=['text', 'vl', 'gate', 'partial-gate'], required=True)
p.add_argument('--rec-url', default='')
a = p.parse_args()
root = Path(__file__).resolve().parent
a.runtime.mkdir(parents=True, exist_ok=True)
os.environ.update({
    'TASK_DB_PATH': str(a.runtime/'tasks.sqlite3'), 'POST_WAIT_MS': '100',
    'PADDLE_OCR_ENABLED': '1' if a.mode == 'vl' else '0',
    'PADDLE_OCR_ENGINE': 'vl', 'PADDLE_VL_VERSION': 'v1.6', 'PADDLE_VL_DEVICE': 'cpu',
    'PADDLE_VL_CPU_THREADS': '4', 'PADDLE_VL_REC_BACKEND': 'llama-cpp-server',
    'PADDLE_VL_REC_SERVER_URL': a.rec_url, 'PADDLE_VL_SERVICE_URL': '',
    'PADDLE_VL_MODEL_DIR': '',
    'PADDLE_VL_LAYOUT_DIR': str(root/'ocr-layout'),
    'PADDLE_PDX_CACHE_HOME': str(a.runtime/'paddle-cache'),
    'PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK': 'True',
    'HF_HOME': str(a.runtime/'hf-cache'), 'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
    'LLM_API_KEY': '', 'LLM_BASE_URL': '', 'LLM_MODEL': '',
    'PYTHONDONTWRITEBYTECODE': '1',
})
for key in ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'HF_TOKEN', 'HUGGING_FACE_HUB_TOKEN']:
    os.environ.pop(key, None)
sys.path.insert(0, str(root/'candidate/backend'))
from app import config
config.DATA_DIR = a.runtime
config.UPLOAD_DIR = a.runtime/'uploads'
config.TASK_DIR = a.runtime/'legacy'
if a.mode in {'gate', 'partial-gate'}:
    from app.pipeline import runner
    original = runner.read_document
    def gated_read(filename, data):
        if a.mode == 'partial-gate' and filename.endswith('.pdf'):
            return original(filename, data)
        marker = a.runtime/f'gate-{threading.get_ident()}.json'
        marker.write_text(json.dumps({'filename': filename, 'input_sha256': hashlib.sha256(data).hexdigest(),
                                     'point': 'runner read_document entry, before inference', 'time': time.time()}), encoding='utf-8')
        # Deliberately wait until this owned process is killed by the driver.
        threading.Event().wait()
    runner.read_document = gated_read
import uvicorn
uvicorn.run('app.main:app', host='127.0.0.1', port=a.port, log_level='warning')
