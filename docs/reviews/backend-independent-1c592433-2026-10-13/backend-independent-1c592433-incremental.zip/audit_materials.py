import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parent
OLD = Path(r'LOCAL_PROJECT_ROOT\tmp\review37-fca14f5-publication\docs\reviews\backend-independent-fca14f5-2026-10-12\review37-fca14f5-independent.zip')
NEW = ROOT / 'candidate/docs/reviews/paddle-vl-server-2026-10-12/server-delivery-evidence.zip'
EXPECTED = {
    'old': '04d959ba3f986824ccc43a18611ef8004cd86bd9e2d23583683183ebe48e258c',
    'author': 'a1bd76d9cf00f6c001e14c19c941d3637b2f3c71e8c410d811d62d0443d7701e',
}
results = {}
for label, path, destination in [('old', OLD, ROOT/'old-materials'), ('author', NEW, ROOT/'author-evidence')]:
    payload = path.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    assert digest == EXPECTED[label], (label, digest)
    destination.mkdir(exist_ok=True)
    members = []
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for member in archive.infolist():
            name = PurePosixPath(member.filename.replace('\\', '/'))
            assert not name.is_absolute() and '..' not in name.parts and ':' not in member.filename
            target = destination.joinpath(*name.parts)
            assert target.resolve().is_relative_to(destination.resolve())
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            data = archive.read(member)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            members.append({'path': member.filename, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    results[label] = {'archive': str(path), 'sha256': digest, 'bytes': len(payload), 'crc_ok': True, 'member_count': len(members), 'members': members}
    manifests = []
    for manifest in destination.rglob('*'):
        if manifest.is_file() and 'manifest' in manifest.name.lower() and manifest.suffix == '.sha256':
            checks = []
            for line in manifest.read_text(encoding='utf-8-sig').splitlines():
                if not line.strip(): continue
                expected, relative = line.split(maxsplit=1)
                relative = relative.lstrip('* ')
                member = manifest.parent / relative
                if not member.exists(): member = destination / relative
                actual = hashlib.sha256(member.read_bytes()).hexdigest()
                checks.append({'path': relative, 'passed': actual == expected.lower(), 'expected': expected.lower(), 'actual': actual})
            manifests.append({'path': str(manifest), 'checks': len(checks), 'passed': all(c['passed'] for c in checks), 'failures': [c for c in checks if not c['passed']]})
    results[label]['manifests'] = manifests
(ROOT/'evidence').mkdir(exist_ok=True)
(ROOT/'evidence/material-integrity.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:{x:y for x,y in v.items() if x != 'members'} for k,v in results.items()}, ensure_ascii=False, indent=2))
