import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root=Path(__file__).resolve().parent
validation=root/'evidence/validation'
live=validation/'live-vl'
live.mkdir(exist_ok=True)
for path in (root/'evidence/interruption/live-vl/after-public').glob('*.json'):
    shutil.copy2(path,live/path.name)
run=subprocess.run([r'NODE_EXE',str(root/'candidate/backend/tools/validate_outputs.mjs'),str(live)],capture_output=True,text=True,encoding='utf-8')
(validation/'live-vl.log').write_text(run.stdout+run.stderr,encoding='utf-8')
assert run.returncode==0,run.stdout+run.stderr
summary=json.loads((validation/'summary.json').read_text())
summary['results'].append({'label':'live-vl','response_count':1,'exit_code':run.returncode,'passed':True,'type':'actual newly obtained HTTP response after real inference interruption'})
summary['total_independent_terminal_responses']=49
(validation/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
visual=root/'evidence/new-vl/pdf-source-inspection.json'
v=json.loads(visual.read_text())
v.update(renderer='Poppler pdftoppm, 150 dpi; read-only source',visual_observation='Page 1 PKGS column has bare 20; no CARTON unit, QTY 500 PCS, NET KG 150.00, GROSS KG 170.00, CBM 1.680; table has no amount column')
visual.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
entries={}
for name in ['INDEPENDENT_REVIEW.md','REPRODUCE.md','serve_review.py','incremental_review.py','live_interruption.py','audit_materials.py','collect_metadata.py','finalize_checks.py','validate_evidence.py','package_evidence.py']:
    entries[name]=(root/name).read_bytes()
for path in (root/'evidence').rglob('*'):
    if not path.is_file():continue
    relative=path.relative_to(root)
    if 'runtime' in relative.parts:continue
    if any(label in relative.parts for label in ['independent','author-saved','live-vl']) and 'validation' in relative.parts:continue
    entries[relative.as_posix()]=path.read_bytes()
originals={}
for request in (root/'evidence').glob('**/requests/*.json'):
    for item in json.loads(request.read_text())['files']:
        path=Path(item['path'])
        data=path.read_bytes()
        assert hashlib.sha256(data).hexdigest()==item['sha256']
        originals[path.relative_to(root).as_posix()]=data
entries.update(originals)
for name in ['old-materials/inputs/dataset/input_sha256.json','old-materials/evidence/digital/destination-country-checks.json',
             'old-materials/inputs/shirt-originals/golden-fields.json','old-materials/inputs/shirt-originals/source-manifest.json',
             'old-materials/evidence/interrupted-restart/summary.json']:
    entries[name]=(root/name).read_bytes()
manifest=''.join(f'{hashlib.sha256(data).hexdigest()}  {name}\n' for name,data in sorted(entries.items()))
entries['MANIFEST.sha256']=manifest.encode('utf-8')
target=root/'backend-independent-1c592433-incremental.zip'
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,data in sorted(entries.items()):archive.writestr(name,data)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for name,data in entries.items():assert archive.read(name)==data
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(root/(target.name+'.sha256')).write_text(f'{digest}  {target.name}\n',encoding='utf-8')
result={'archive':str(target),'sha256':digest,'bytes':target.stat().st_size,'members':len(entries),'originals':len(originals),
        'crc_and_all_members_checked':True,'excludes':['models','runtime databases','caches','credentials','production config','author restart scripts']}
(root/'DELIVERY.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
