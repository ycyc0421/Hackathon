import copy
import hashlib
import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parent
out=root/'evidence/new-vl'
task=json.loads((out/'public/SHIRT-PL-NEW-VL.json').read_text(encoding='utf-8'))
checks=json.loads((out/'checks.json').read_text(encoding='utf-8'))
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'))
# The initial driver looked for parse_method on Document, but the contract puts it on Extraction.
# Retain that first assessment and fix only the assertion, without new inference or response edits.
if checks[0]['passed'] is False and task['documents'][0]['process_status']=='EXTRACTED' and task['extractions'][0]['parse_method']=='OCR':
    (out/'initial-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'initial-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    checks[0].update(passed=True,parse_method=task['extractions'][0]['parse_method'],
                     assessment_correction='Harness initially checked parse_method in documents; contract stores it in extractions. Same saved actual response; no new inference.')
    summary.update(passed=sum(c['passed'] for c in checks),failed=[c for c in checks if not c['passed']],
                   assessment_correction=checks[0]['assessment_correction'])
    (out/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
sys.path.insert(0,str(root/'candidate/backend'))
from app.pipeline.normalize import to_country,to_measure
from app.pipeline.compare import build_item_comparisons
from app.pipeline.align import align_items

boundary=[]
for raw,expected in [('SG','SG'),('AU','AU'),('Singapore','SG'),('Australia','AU'),('新加坡','SG'),('澳大利亚','AU')]:
    actual=to_country(raw)
    boundary.append({'kind':'pure normalization boundary, no new model inference','raw':raw,'expected':expected,'actual':actual,'passed':actual==expected})
for raw,expected in [('20',(20,None)),('20 PKGS',(20,None)),('20 PACKAGES',(20,None)),('20 CTNS',(20,'CARTON')),('20 CARTONS',(20,'CARTON')),('20 箱',(20,'CARTON'))]:
    actual=to_measure(raw,'packages')
    boundary.append({'kind':'pure normalization boundary, no new model inference','raw':raw,'expected':expected,'actual':actual,'passed':actual==expected})
# Recompute comparison from the freshly extracted PL, with two identical sources.
# This is a saved-result comparison check, explicitly not a second upload or model inference.
with __import__('sqlite3').connect(f'file:{(out/"runtime/tasks.sqlite3").as_posix()}?mode=ro',uri=True) as conn:
    internal=json.loads(conn.execute('SELECT payload_json FROM api_task_payloads WHERE task_id=?',(task['task_id'],)).fetchone()[0])
docs=[copy.deepcopy(internal['documents'][0]) for _ in range(2)]
exts=[copy.deepcopy(internal['extractions'][0]) for _ in range(2)]
for n,(doc,ext) in enumerate(zip(docs,exts),1):doc['file_id']=ext['file_id']=f'f{n}'
items=align_items(exts,docs)
comparisons=build_item_comparisons(items,docs,exts,lambda *_:False)
packages=[c for c in comparisons if c['field_key']=='packages']
boundary.append({'kind':'comparison recomputation from saved fresh PL extraction; no second inference',
                 'check':'two unknown package units must remain NOT_CHECKED',
                 'passed':bool(packages) and all(c['status']=='NOT_CHECKED' for c in packages),'comparisons':packages})
(root/'evidence/boundary-checks.json').write_text(json.dumps(boundary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'boundary_checks':len(boundary),'passed':sum(c['passed'] for c in boundary),'failed':[c for c in boundary if not c['passed']]},ensure_ascii=False))

# Render the unchanged original with the already installed PyMuPDF for visual source checking.
import pymupdf
pdf=root/'old-materials/inputs/shirt-originals/exportdoc-packing-list-sample.pdf'
with pymupdf.open(pdf) as document:
    document[0].get_pixmap(dpi=150).save(str(out/'original-packing-list.png'))
    (out/'pdf-source-inspection.json').write_text(json.dumps({'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
        'pages':len(document),'native_text':document[0].get_text(),
        'renderer':'existing PyMuPDF; read-only original, no file modification'},ensure_ascii=False,indent=2),encoding='utf-8')
