import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
repo=root/'candidate'
modules=Path(r'LOCAL_PROJECT_ROOT\tmp\review37-fca14f5-20261012\node_modules')
shutil.copytree(modules,repo/'node_modules',dirs_exist_ok=True)
output=root/'evidence/validation'
output.mkdir(exist_ok=True)
independent=list((root/'evidence/country/public').glob('*.json'))+list((root/'evidence/new-vl/public').glob('*.json'))
independent+=list((root/'evidence/interruption').glob('*/after-public/*.json'))
authors=list((root/'author-evidence/digital/public').glob('*.json'))
authors += [root/'author-evidence/extra-final/scan-public.json',root/'author-evidence/final-server-acceptance/public.json']
results=[]
for label,paths in [('independent',independent),('author-saved',authors)]:
    target=output/label
    target.mkdir(exist_ok=True)
    for n,path in enumerate(paths,1):
        assert path.exists(),str(path)
        shutil.copy2(path,target/f'{n:03d}-{path.name}')
    run=subprocess.run([r'NODE_EXE',str(repo/'backend/tools/validate_outputs.mjs'),str(target)],cwd=repo,capture_output=True,text=True,encoding='utf-8')
    (output/f'{label}.log').write_text(run.stdout+run.stderr,encoding='utf-8')
    results.append({'label':label,'response_count':len(paths),'exit_code':run.returncode,'passed':run.returncode==0,
                    'type':'actual newly obtained HTTP responses' if label=='independent' else 'author saved-output schema validation; NOT new HTTP/model inference'})
    assert run.returncode==0,run.stdout+run.stderr
# Verify every original actually used remains identical to its pre-upload hash.
originals={}
for request in (root/'evidence').glob('**/requests/*.json'):
    for item in json.loads(request.read_text(encoding='utf-8'))['files']:
        path=Path(item['path'])
        actual=hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual==item['sha256'],str(path)
        originals[str(path)]={'expected_sha256':item['sha256'],'after_sha256':actual,'passed':True}
(output/'summary.json').write_text(json.dumps({'results':results,'different_originals_checked_after':len(originals)},ensure_ascii=False,indent=2),encoding='utf-8')
(root/'evidence/originals-after.json').write_text(json.dumps(originals,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'results':results,'different_originals_checked_after':len(originals)},ensure_ascii=False,indent=2))
