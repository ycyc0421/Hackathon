"""Interrupt the newly created API while its first old scan is in real VL inference."""
import json
from pathlib import Path
import subprocess
import time
import httpx
from incremental_review import ROOT, DATA, OUT, PIN, Server, port, save, digest, internal_snapshot, stop_owned, CHILD_ENV, CREATION

output=OUT/'interruption/live-vl'
actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT/'candidate',text=True).strip()
assert actual==PIN,actual
output.mkdir(parents=True,exist_ok=True)
engine=Path(r'LOCAL_PROJECT_ROOT\ocr-local\runtime\llama-b11560-vulkan\llama-server.exe')
models=Path(r'LOCAL_PROJECT_ROOT\ocr-local\models\PaddleOCR-VL-1.6')
recport=port()
command=[str(engine),'-m',str(models/'PaddleOCR-VL-1.6-GGUF.gguf'),'--mmproj',str(models/'PaddleOCR-VL-1.6-GGUF-mmproj.gguf'),
         '--host','127.0.0.1','--port',str(recport),'--device','Vulkan1','--mmproj-device','Vulkan1','-ngl','all',
         '-c','8192','--parallel','1','--temp','0','--alias','paddleocr-vl-1.6','--no-warmup']
log=(output/'llama.log').open('wb')
process=None;server=None;checks=[]
try:
    process=subprocess.Popen(command,env=CHILD_ENV,stdout=log,stderr=subprocess.STDOUT,creationflags=CREATION)
    save(output/'llama-process.json',{'pid':process.pid,'owned_process':True,'command':command})
    with httpx.Client(timeout=5,trust_env=False) as client:
        for _ in range(600):
            if process.poll() is not None:raise RuntimeError('owned llama exited')
            try:
                if client.get(f'http://127.0.0.1:{recport}/health').status_code==200:break
            except httpx.HTTPError:pass
            time.sleep(.1)
        else:raise TimeoutError('llama startup')
    server=Server(output,'vl',f'http://127.0.0.1:{recport}/v1')
    paths=[DATA/'backend/samples/SHP-00001'/name for name in ['commercial_invoice.scan.png','packing_list.scan.png','proforma_invoice.scan.png']]
    task=server.upload('OLD-SCAN-GROUP-LIVE-VL',paths,wait=False)
    task_id=task['task_id']
    deadline=time.monotonic()+240
    while time.monotonic()<deadline:
        text=(output/'llama.log').read_text(encoding='utf-8',errors='replace')
        if 'processing task, is_child' in text:break
        state=server.get(task_id)
        if state['status'] not in {'PENDING','PROCESSING'}:
            save(output/'unexpected-terminal.json',state)
            raise RuntimeError('task finished before live inference interruption')
        time.sleep(.2)
    else:raise TimeoutError('no evidence of actual VL recognition')
    task=server.get(task_id)
    save(output/'before-public.json',task)
    save(output/'before-internal.json',internal_snapshot(server.runtime))
    save(output/'inference-marker.json',{'evidence':'owned llama log processing task after original scan upload','lines':text.splitlines()[-12:],
         'time':time.time(),'task_status':task['status'],'reader_pause_or_output_mock':False})
    checks.append({'check':'API actually processing new VL inference before kill','passed':task['status']=='PROCESSING'})
    checks.append({'check':'all three accepted documents published while first scan in inference','passed':len(task['documents'])==3})
    for n,path in enumerate(paths,1):
        source=server.runtime/'uploads'/task_id/f'f{n}.source'
        checks.append({'check':f'f{n} durable before live inference ends','passed':source.exists() and digest(source)==digest(path)})
    killed_pid=server.process.pid
    server.close()
    save(output/'killed-process.json',{'pid':killed_pid,'action':'Popen.kill / Windows TerminateProcess','owned_process':True,
                                      'actual_vl_inference_started':True,'production_access':False})
    server=Server(output,'text')
    task=server.get(task_id)
    save(output/'after-public'/f'{task_id}.json',task)
    statuses=[d['process_status'] for d in task['documents']]
    checks.append({'check':'TASK_INTERRUPTED terminal after real inference kill','passed':task['status']=='FAILED' and bool(task['finished_at'])
                  and any(e['code']=='TASK_INTERRUPTED' for e in task['errors'])})
    checks.append({'check':'all three document states finalized','passed':len(statuses)==3 and all(s=='FAILED' for s in statuses),'states':statuses})
    server.report(task_id,task_id)
    for n,path in enumerate(paths,1):checks.append(dict(server.download(task_id,f'f{n}',path),check=f'f{n} original after live inference kill'))
    save(output/'checks.json',checks)
    summary={'source_commit':PIN,'task_count':1,'original_count':3,'checks':len(checks),'passed':sum(c['passed'] for c in checks),
             'failed':[c for c in checks if not c['passed']],'method':'real old SHP-00001 scans, new VL inference, real owned API kill/restart; no reader mock'}
    save(output/'summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)
finally:
    if server:server.close()
    stop_owned(process);log.close()
