import json
from pathlib import Path
import httpx
OUT=Path(__file__).resolve().parent;origin='https://hackathon.ychome.net'
with httpx.Client(timeout=30,headers={'User-Agent':'Hackathon-B-readonly-diagnostic','Accept':'application/json'}) as client:
    results={}
    for name,path in [('health','/health'),('capabilities','/api/v1/capabilities'),('edi-task','/api/v1/checks/tsk_20261014_0016_4ca5b008bbf9'),('mixed-task','/api/v1/checks/tsk_20261014_0017_1a29c18496be')]:
        r=client.get(origin+path);r.raise_for_status();d=r.json();(OUT/(name+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        results[name]={'release_revision':d.get('release_revision'),'status':d.get('status'),'formats':d.get('formats'),'documents':d.get('documents'),'errors':d.get('errors')}
    print(json.dumps(results,ensure_ascii=False))
