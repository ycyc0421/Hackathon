"""Trace unchanged backend via local HTTP; no server/model operation."""
import hashlib,json,os,sys,time
from pathlib import Path
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;REPO=Path('D:/hackson/tmp/edi-root-20261014');STATE=OUT/'isolated';STATE.mkdir(parents=True,exist_ok=True)
os.environ.update(TASK_DB_PATH=str(STATE/'initial.db'),PADDLE_OCR_ENABLED='1',PADDLE_OCR_ENGINE='vl',PADDLE_VL_SERVICE_URL='',LLM_BASE_URL='',LLM_API_KEY='',POST_WAIT_MS='0')
sys.path.insert(0,str(REPO/'backend'))
from fastapi.testclient import TestClient
from app import main,config
from app.pipeline import runner,reader
from app.sqlite_store import TaskStore
store=TaskStore(STATE/'tasks.db',STATE/'legacy')
def save(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
control={'format':'hackathon-trade-json-v1','doc_type':'COMMERCIAL_INVOICE','fields':{'document_no':'SYN-EDI-ROOT-JSON-CONTROL','invoice_no':'SYN-EDI-ROOT-JSON-CONTROL','currency':'USD','total_amount':'4800.00'},'line_items':[{'item_no':1,'fields':{'item_code':'MUG350','description':'CERAMIC MUG 350ML WHITE','quantity':'2400 PCS','unit_price':'2.00','amount':'4800.00'}}]}
raw=json.dumps(control).encode('utf-8');(OUT/'project-json-control.json').write_bytes(raw)
entries=[('expected-complete-invoic',REPO/'backend/samples/edi/01_consistent/01_invoic.edi'),('bad-UNT-count',REPO/'backend/samples/edi/11_bad_unt_count/01_invoic.edi'),('truncated-EDI',REPO/'backend/samples/edi/12_truncated/01_desadv.edi')]
results=[];checks=[]
def check(n,p,a=None):checks.append({'name':n,'passed':bool(p),'actual':a})
classification={name:reader.guess_file_type(name).value for name in ['invoice.edi','INVOICE.EDI','invoice.x12','invoice.txt','invoice.json']}
save('file-classification.json',classification)
with patch.object(main,'store',store),patch.object(runner,'store',store),patch.object(main,'UPLOAD_DIR',STATE/'uploads'),patch.object(runner,'UPLOAD_DIR',STATE/'uploads'),patch.object(config,'DATA_DIR',STATE),patch.object(config,'TASK_DIR',STATE/'legacy'),patch.object(config,'UPLOAD_DIR',STATE/'uploads'),patch.object(runner,'read_document',wraps=reader.read_document) as read_calls,patch.object(reader,'_read_image',wraps=reader._read_image) as image_calls,patch.object(reader,'_read_pdf',wraps=reader._read_pdf) as pdf_calls,TestClient(main.app) as client:
    for name,path in entries:
        data=path.read_bytes();before=(read_calls.call_count,image_calls.call_count,pdf_calls.call_count)
        created=client.post('/api/v1/checks',data={'destination_country':'US'},files=[('files',(path.name,data,'application/edifact'))]);created.raise_for_status();tid=created.json()['task_id']
        for _ in range(100):
            r=client.get('/api/v1/checks/'+tid);r.raise_for_status();task=r.json()
            if task['status'] not in ['PENDING','PROCESSING']:break
            time.sleep(.05)
        save(name+'-task.json',task)
        after=(read_calls.call_count,image_calls.call_count,pdf_calls.call_count);calls=dict(zip(['read_document','image_or_OCR','pdf_or_OCR'],[b-a for a,b in zip(before,after)]))
        original=client.get('/api/v1/checks/'+tid+'/files/f1')
        result={'case':name,'task_id':tid,'status':task['status'],'file_type':task['documents'][0]['file_type'],'document_status':task['documents'][0]['process_status'],'error_codes':[e['code'] for e in task['errors']],'calls':calls,'source':str(path.relative_to(REPO)).replace('\\','/'),'sha256':hashlib.sha256(data).hexdigest(),'original_identical':original.content==data}
        results.append(result)
        check(name+' rejects before reader/OCR',task['status']=='FAILED' and task['documents'][0]['process_status']=='UNSUPPORTED' and all(n==0 for n in calls.values()),result)
        check(name+' original preserved',original.is_success and original.content==data)
    before=(read_calls.call_count,image_calls.call_count,pdf_calls.call_count)
    created=client.post('/api/v1/checks',data={'destination_country':'US'},files=[('files',('project-control.json',raw,'application/json'))]);created.raise_for_status();tid=created.json()['task_id']
    for _ in range(100):
        task=client.get('/api/v1/checks/'+tid).json()
        if task['status'] not in ['PENDING','PROCESSING']:break
        time.sleep(.05)
    save('project-json-control-task.json',task)
    after=(read_calls.call_count,image_calls.call_count,pdf_calls.call_count)
    result={'case':'project-json-control','task_id':tid,'status':task['status'],'file_type':task['documents'][0]['file_type'],'parse_method':task['extractions'][0]['parse_method'],'calls':dict(zip(['read_document','image_or_OCR','pdf_or_OCR'],[b-a for a,b in zip(before,after)]))};results.append(result)
    check('EDI_PARSE is currently project JSON route only',task['status']=='COMPLETED' and task['extractions'][0]['parse_method']=='EDI_PARSE' and result['calls']=={'read_document':1,'image_or_OCR':0,'pdf_or_OCR':0},result)
save('local-trace.json',{'commit':'852cc57736a0347fb21533d9f4f90a8a66b19812','mode':'isolated real FastAPI HTTP; call spies wrap original functions without replacing responses','ocr_configured':True,'classification':classification,'results':results,'checks':checks,'failed':[c for c in checks if not c['passed']],'limits':['No standard EDI parser invoked or supplied','No production mutation','Project JSON control is explicitly synthetic and not standard EDI']})
print(json.dumps({'classification':classification,'results':results,'checks':len(checks),'failed':[c for c in checks if not c['passed']]},ensure_ascii=False))
