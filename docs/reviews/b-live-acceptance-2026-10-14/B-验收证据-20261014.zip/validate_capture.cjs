const fs=require('node:fs'),path=require('node:path');
const Ajv=require('D:/hackson/tmp/followup-main-d223d7c-20261012/node_modules/ajv/dist/2020.js').default;
const repo='D:/hackson/tmp/acceptance-main-20261014',root=__dirname,ajv=new Ajv({allErrors:true,strict:false}),checks=[];
const schemas={tasks:'check-task',reports:'report-content',evaluation:'evaluation'};
for(const [folder,name] of Object.entries(schemas)){
 const validate=ajv.compile(JSON.parse(fs.readFileSync(path.join(repo,'docs/schema/'+name+'.schema.json'))));
 const files=folder==='evaluation'?['evaluation.json']:fs.readdirSync(path.join(root,folder)).filter(n=>n.endsWith('.json'));
 for(const file of files){
  const data=JSON.parse(fs.readFileSync(path.join(root,folder==='evaluation'?'meta':folder,file)));
  checks.push({case:folder+'/'+file,name:'current schema',passed:!!validate(data),errors:validate.errors});
  if(folder==='tasks'){
   const counts={document_count:data.documents.length,field_count:data.extractions.reduce((s,e)=>s+e.fields.length,0),item_count:data.items.length,conflict_count:data.comparisons.filter(c=>c.status==='CONFLICT').length,missing_count:data.comparisons.filter(c=>c.status==='MISSING_IN_SOME').length,risk_count:data.risks.length,unrecognized_count:data.comparisons.filter(c=>c.status==='UNRECOGNIZED').length};
   const countProblems=Object.entries(counts).filter(([k,v])=>k in data.summary&&data.summary[k]!==v);
   const fids=new Set(data.documents.map(d=>d.file_id)),iids=new Set(data.items.map(i=>i.item_id)),problems=[];
   for(const e of data.extractions){if(!fids.has(e.file_id))problems.push('extraction file');for(const f of e.fields)if(f.item_id&&!iids.has(f.item_id))problems.push('field item');}
   for(const c of data.comparisons){if(c.item_id&&!iids.has(c.item_id))problems.push('comparison item');for(const v of c.values){if(!fids.has(v.file_id))problems.push('value file');if(v.item_id&&!iids.has(v.item_id))problems.push('value item');}}
   checks.push({case:folder+'/'+file,name:'summary and references',passed:countProblems.length===0&&problems.length===0&&fids.size===data.documents.length&&iids.size===data.items.length,errors:[...countProblems,...problems]});
  }
 }
}
fs.writeFileSync(path.join(root,'contract-validation.json'),JSON.stringify({checks:checks.length,failed:checks.filter(c=>!c.passed),details:checks},null,2));console.log(JSON.stringify({checks:checks.length,failed:checks.filter(c=>!c.passed)}));process.exitCode=checks.some(c=>!c.passed)?1:0;
