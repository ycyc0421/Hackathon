"""Bounded public acceptance: sequential uploads, originals preserved, no server mutation."""
import hashlib, importlib.util, json, mimetypes, re, sys, time
from datetime import datetime, timezone
from pathlib import Path
import httpx

OUT=Path(__file__).resolve().parent
REPO=Path('D:/hackson/tmp/acceptance-main-20261014')
DATA=Path('D:/hackson/ocr-local/inputs/trade_documents_hackathon_v2/trade_documents_hackathon_v2')
ORIGIN='https://hackathon.ychome.net'
SHA='e4d7f23daf84fd0235b62ca7e8ae1d19370aa828'
for name in ['tasks','reports','archives','meta','derived-inputs']: (OUT/name).mkdir(parents=True,exist_ok=True)
checks=[]; cases=[]; manifests=[]
def save(path,obj):
    (OUT/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def check(case,name,passed,actual=None):
    checks.append(dict(case=case,name=name,passed=bool(passed),actual=actual))
def persist():
    save('summary.json',dict(commit=SHA,origin=ORIGIN,recorded_at=datetime.now(timezone.utc).isoformat(),mode='independent live HTTP; sequential real OCR, no response replay',cases=cases,checks=len(checks),failed=[c for c in checks if not c['passed']],limits=['Bounded cases, not dataset-wide accuracy','No production restart or private server log inspection','Unverified rules cannot establish legal compliance']))
    save('checks.json',checks);save('input-manifest.json',manifests)
def fields(ex): return {f['field_key']:f for f in ex['fields']}
def public_rows(ex):
    rows={}
    for f in ex['fields']:
        if f.get('item_id'):
            rows.setdefault((f['item_id'],f.get('line_no')),[]).append(f)
    return [{'fields':fs} for fs in rows.values()]
def same(a,b):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return abs(a-b)<=1e-6*max(1,abs(b))
    return a==b

with httpx.Client(timeout=60,headers={'User-Agent':'Hackathon-B-readonly-diagnostic','Origin':ORIGIN,'Accept':'application/json'},follow_redirects=True) as client:
    def get(path):
        r=client.get(ORIGIN+path);r.raise_for_status();return r.json()
    start=get('/health');save('meta/health-start.json',start)
    check('environment','deployed SHA matches pinned main',start.get('release_revision')==SHA,start)
    for path,name in [('/api/v1/capabilities','capabilities'),('/api/v1/evaluation/latest','evaluation')]:save('meta/'+name+'.json',get(path))
    r=client.get(ORIGIN+'/api/v1/evaluation/runs');save('meta/evaluation-runs.json',{'http_status':r.status_code,'body':r.json()})
    check('environment','evaluation history remains unmerged',r.status_code==404,r.status_code)
    r=client.options(ORIGIN+'/api/v1/checks',headers={'Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type'})
    check('environment','CORS upload preflight',r.is_success and 'POST' in r.headers.get('access-control-allow-methods','') and r.headers.get('access-control-allow-origin') in ['*',ORIGIN],r.status_code)
    r=client.get(ORIGIN+'/');check('frontend','root mount available',r.is_success and 'id="app"' in r.text,r.status_code)
    for asset in re.findall(r'(?:src|href)="(/assets/[^"]+)"',r.text):
        ar=client.get(ORIGIN+asset);check('frontend','asset '+asset,ar.is_success,ar.status_code)
    r=client.get(ORIGIN+'/api/v1/checks/tsk_B_acceptance_missing');check('environment','missing task 404',r.status_code==404,r.status_code)

    suite=[]
    for name,country in [('01_us_consistent','US'),('02_de_conflict','DE'),('04_de_multiitem','DE')]:
        suite.append((name,country,sorted((REPO/'backend/samples'/name).glob('*.pdf')),'COMPLETED'))
    for num in [2,7,11,97]:
        name=f'SHP-{num:05d}'
        suite.append((name,'GB' if num==2 else 'DE',[DATA/'backend/samples'/name/(s+'.pdf') for s in ['commercial_invoice','packing_list','proforma_invoice']],'COMPLETED'))
    edi=REPO/'docs/fixtures/edi/invoice.edi'
    suite += [('edi-only','DE',[edi],'FAILED'),('mixed-pdf-edi','DE',[edi,REPO/'docs/fixtures/edi/synthetic-packing-list.pdf'],'PARTIAL')]
    suite += [('shirt-originals','US',sorted((REPO/'backend/samples/shirt-originals').glob('*.pdf')),'COMPLETED'),('ocr_png','DE',sorted((REPO/'backend/samples/11_de_multiitem_mixed').glob('*.png')),'COMPLETED')]
    spec=importlib.util.spec_from_file_location('smoke',REPO/'deploy/smoke.py');smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
    import os
    previous=os.getcwd();os.chdir(REPO)
    scan=[]
    for _,(name,body,mime) in smoke.ocr_uploads(scan=True):
        p=OUT/'derived-inputs'/name;p.write_bytes(body);scan.append(p)
    os.chdir(previous)
    suite.append(('ocr_scan','DE',scan,'COMPLETED'))

    for name,country,paths,expected_status in suite:
        started=time.monotonic();print('START '+name,flush=True)
        entries=[dict(name=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,origin='derived image-only scan PDF' if name=='ocr_scan' else 'unchanged source file') for p in paths]
        manifests.append(dict(case=name,files=entries));persist()
        try:
            files=[('files',(p.name,p.read_bytes(),mimetypes.guess_type(p.name)[0] or 'application/octet-stream')) for p in paths]
            r=client.post(ORIGIN+'/api/v1/checks',files=files,data={'destination_country':country,'notes':'B 独立验收 2026-10-14；原件/合成样例，非正式法规验收'})
            r.raise_for_status();created=r.json();save('meta/'+name+'-created.json',created)
            tid=created['task_id'];deadline=time.monotonic()+1200
            while True:
                task=get('/api/v1/checks/'+tid);save('tasks/'+name+'.json',task)
                if task['status'] not in ['PENDING','PROCESSING']:break
                if time.monotonic()>deadline:raise TimeoutError('Task deadline exceeded: '+tid)
                time.sleep(3)
            cases.append(dict(case=name,task_id=tid,status=task['status'],expected_status=expected_status,elapsed_s=round(time.monotonic()-started,2),items=len(task['items']),summary=task['summary'],errors=[e['code'] for e in task['errors']]))
            check(name,'terminal status',task['status']==expected_status,task['status'])
            if expected_status=='COMPLETED':check(name,'all originals extracted',len(task['documents'])==len(paths) and all(d['process_status']=='EXTRACTED' for d in task['documents']))
            docs={d['file_id']:d for d in task['documents']}
            expected_files={p.name:p for p in paths}
            for doc in task['documents']:
                original=client.get(ORIGIN+'/api/v1/checks/'+tid+'/files/'+doc['file_id'])
                check(name,'original byte identity '+doc['file_name'],original.is_success and original.content==expected_files[doc['file_name']].read_bytes())
            for view,folder in [('content','reports'),('archive','archives')]:
                report=get('/api/v1/checks/'+tid+'/report?format=json&view='+view);save(folder+'/'+name+'.json',report)
                check(name,'report view '+view,report.get('report_version')=='2' and report.get('view')==view)
            for ex in task['extractions']:
                allfields=ex['fields']+[f for row in ex.get('line_items',[]) for f in row['fields']]
                for f in allfields:
                    if f.get('normalized_value') is not None and f.get('status') not in ['NOT_IN_DOC','NOT_APPLICABLE','UNREADABLE']:
                        check(name,'source evidence '+docs[ex['file_id']]['file_name']+' '+str(f.get('line_no'))+' '+f['field_key'],f.get('page') is not None and bool(f.get('raw_text')))
            if name=='01_us_consistent':check(name,'no fabricated conflicts',task['summary']['conflict_count']==0)
            if name=='02_de_conflict':check(name,'real conflict detected',task['summary']['conflict_count']>0)
            if name=='04_de_multiitem':check(name,'four SKUs retained',len(task['items'])==4)
            if name.startswith('SHP-'):
                # Gold values are read only after predictions have been saved.
                num=int(name[4:]);stem={'commercial_invoice.pdf':'ci','packing_list.pdf':'pl','proforma_invoice.pdf':'pi'}
                supported={'document_no','invoice_no','item_code','quantity','packages','net_weight','gross_weight','volume','amount','unit_price','total_amount','hs_code'}
                for ex in task['extractions']:
                    filename=docs[ex['file_id']]['file_name'];gold=json.loads((DATA/f'docs/fixtures/raw/f_{stem[filename]}_{num:05d}.json').read_text(encoding='utf-8'))
                    actual={(f['field_key'],f.get('line_no')):f for f in ex['fields']}
                    for f in gold['fields']:
                        if f['field_key'] in supported:
                            af=actual.get((f['field_key'],f.get('line_no')),{});check(name,'gold '+filename+' '+str(f.get('line_no'))+' '+f['field_key'],same(af.get('normalized_value'),f['normalized_value']),{'expected':f['normalized_value'],'actual':af.get('normalized_value'),'actual_status':af.get('status')})
                if num==2:
                    quantities=[c for c in task['comparisons'] if c['field_key']=='quantity' and c['status']=='CONFLICT']
                    check(name,'880/888 quantity conflict with both evidence sides',any({v.get('normalized_value') for v in c['values']}=={880,888} and all(v.get('page') and v.get('raw_value') for v in c['values']) for c in quantities),quantities)
                    check(name,'different document IDs never compared for equality',not any(c['field_key']=='document_no' for c in task['comparisons']))
            if name=='shirt-originals':
                for ex in task['extractions']:
                    filename=docs[ex['file_id']]['file_name'];packing='packing-list' in filename
                    prefix='PL' if packing else ('PI' if 'proforma' in filename else 'CI')
                    fs=fields(ex)
                    for k,v in {'document_no':prefix+'-20260830-08300186','shipper':'NINGBO QIHANG EXPORT CO., LTD','consignee':'GLOBAL FASHION INC',**({} if packing else {'total_amount':1400})}.items():check(name,'shirt '+filename+' '+k,same(fs[k]['normalized_value'],v),fs[k]['normalized_value'])
                    rows=public_rows(ex)
                    check(name,'shirt one SKU '+filename,len(rows)==1)
                    if rows:
                        row=fields(rows[0]);expected={'item_code':'CT-2408','quantity':500,**({'packages':20,'net_weight':150,'gross_weight':170,'volume':1.68} if packing else {'unit_price':2.8,'amount':1400})}
                        for k,v in expected.items():check(name,'shirt row '+filename+' '+k,same(row[k]['normalized_value'],v),row[k]['normalized_value'])
                        if packing:
                            for k,f in [('total_amount',fs['total_amount']),('amount',row['amount'])]:check(name,'PL no fabricated '+k,f['normalized_value'] is None and f['status']=='NOT_IN_DOC',f)
                check(name,'description is consistent or explicitly unverified',all(c['status']=='MATCH' or (c['status']=='NOT_CHECKED' and c.get('note')) for c in task['comparisons'] if c['field_key']=='description'))
            if name in ['ocr_png','ocr_scan']:
                check(name,'real OCR channel all files',len(task['extractions'])==3 and all(ex['parse_method']=='OCR' for ex in task['extractions']))
                check(name,'four SKUs through OCR',len(task['items'])==4)
                check(name,'real color difference conflict',any(c['field_key']=='description' and c.get('item_id') and c['status']=='CONFLICT' for c in task['comparisons']))
            if name in ['edi-only','mixed-pdf-edi']:check(name,'EDI explicitly unsupported',any(d['process_status']=='UNSUPPORTED' and d['file_name']==edi.name for d in task['documents']))
            print('DONE '+json.dumps(cases[-1],ensure_ascii=False),flush=True)
        except Exception as e:
            check(name,'execution completed',False,{'kind':type(e).__name__,'message':str(e)[:300]});print('ERROR '+name+' '+type(e).__name__+' '+str(e)[:200],flush=True)
        persist()

    # Bounded correction on our own synthetic task; real invoices untouched.
    source=json.loads((OUT/'tasks/01_us_consistent.json').read_text(encoding='utf-8'));tid=source['task_id']
    metadata=get('/api/v1/checks/'+tid+'/corrections');save('meta/correction-context.json',metadata)
    ex=next(e for e in source['extractions'] if fields(e)['packages']['normalized_value'] is not None)
    field=fields(ex)['packages'];new_value=str(field['normalized_value']+1)+' '+(field.get('unit') or '')
    payload={'request_id':'B-acceptance-20261014-'+tid,'source_hash':metadata['result_hash'],'reason':'合成验收任务：模拟修改包装数，验证重算、版本与幂等；非原件识别结果','changes':[{'file_id':ex['file_id'],'field_key':'packages','value':new_value}]}
    r=client.post(ORIGIN+'/api/v1/checks/'+tid+'/corrections',json=payload);r.raise_for_status();child=r.json();save('meta/correction-created.json',child)
    child_task=get('/api/v1/checks/'+child['task_id']);save('tasks/corrected.json',child_task)
    check('correction','new revision and original immutable',child['task_id']!=tid and get('/api/v1/checks/'+tid)==source)
    revised=next(e for e in child_task['extractions'] if e['file_id']==ex['file_id']);rf=fields(revised)['packages']
    check('correction','source evidence retained',all(field.get(k)==rf.get(k) for k in ['raw_value','raw_text','page','bbox','confidence']))
    check('correction','comparison recomputed',any(c['field_key']=='packages' and c['status']=='CONFLICT' for c in child_task['comparisons']))
    retry=client.post(ORIGIN+'/api/v1/checks/'+tid+'/corrections',json=payload);check('correction','retry idempotence',retry.is_success and retry.json()['task_id']==child['task_id'])
    stale={**payload,'request_id':payload['request_id']+'-stale','source_hash':'0'*64};r=client.post(ORIGIN+'/api/v1/checks/'+tid+'/corrections',json=stale);check('correction','stale hash rejected',r.status_code==409,r.status_code)
    for view,folder in [('content','reports'),('archive','archives')]:save(folder+'/corrected.json',get('/api/v1/checks/'+child['task_id']+'/report?format=json&view='+view))
    r=client.get(ORIGIN+'/api/v1/checks/'+tid+'/report?format=html');check('report','HTML moved to frontend explicitly',r.status_code==410 and r.json()['error']['code']=='REPORT_PRESENTATION_MOVED',r.status_code)
    end=get('/health');save('meta/health-end.json',end);check('environment','same deployed revision at end',end.get('release_revision')==SHA,end)
    persist();print('FINAL '+json.dumps({'cases':len(cases),'checks':len(checks),'failed':len([c for c in checks if not c['passed']])}),flush=True)
