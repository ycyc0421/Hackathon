"""New main: saved-result API and negative states, isolated local files only."""
import copy,hashlib,json,logging,os,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
REPO=Path('D:/hackson/tmp/acceptance-e82465b-20261014')
LOCAL=OUT/'evaluation-e82465b-api-store';LOCAL.mkdir(exist_ok=True)
os.environ.update(TASK_DB_PATH=str(LOCAL/'tasks.db'),PADDLE_OCR_ENABLED='0',LLM_BASE_URL='',LLM_API_KEY='',EVALUATION_RESULT_PATH=str(LOCAL/'latest.json'))
sys.path.insert(0,str(REPO/'backend'))
from fastapi.testclient import TestClient
from app import config,main,evaluation
from app.sqlite_store import TaskStore
from tools.evaluate_dataset import publish
from unittest.mock import patch
logging.getLogger('httpx').setLevel(logging.WARNING)
data=json.loads((OUT/'evaluation-e82465b-test-text-run3/evaluation.json').read_text(encoding='utf-8'))
checks=[]
def check(name,passed,actual=None):checks.append(dict(name=name,passed=bool(passed),actual=actual))
store=TaskStore(LOCAL/'isolated.db',LOCAL/'legacy')
with patch.object(main,'store',store),patch.object(config,'DATA_DIR',LOCAL),patch.object(config,'TASK_DIR',LOCAL/'legacy'),patch.object(config,'UPLOAD_DIR',LOCAL/'uploads'),TestClient(main.app) as client:
    absent=client.get('/api/v1/evaluation/latest').json();check('missing summary NOT_RUN',absent['status']=='NOT_RUN' and absent['metrics'] is None)
    publish(data,LOCAL)
    r=client.get('/api/v1/evaluation/latest');actual=r.json();(OUT/'evaluation-e82465b-api-latest.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2),encoding='utf-8')
    check('actual scored result served',r.status_code==200 and actual['metrics']==data['metrics'] and actual['scope']==data['scope'])
    for name,count in data['scope']['counts'].items():
        tp,fp,fn=[count[k] for k in ['tp','fp','fn']]
        expected={'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn) if tp+fn else None,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None}
        check('independent arithmetic '+name,data['metrics'][name]==expected,expected)
    first=[p for p in (LOCAL/'runs').glob('*.json')][0];first_hash=hashlib.sha256(first.read_bytes()).hexdigest()
    history=client.get('/api/v1/evaluation/runs').json();check('history reads persisted run',len(history)==1 and history[0]['scope']==data['scope'])
    with TestClient(main.app) as reopened:check('new API client reads saved result',reopened.get('/api/v1/evaluation/latest').json()==actual)
    tampered=copy.deepcopy(data);tampered['metrics']['field_extraction']['f1']=1.0
    try:publish(tampered,LOCAL);check('fake perfect score rejected',False)
    except ValueError:check('fake perfect score rejected',True)
    check('invalid publish preserves old result',client.get('/api/v1/evaluation/latest').json()==actual)
    check('history immutable after rejected publish',hashlib.sha256(first.read_bytes()).hexdigest()==first_hash)
    missing_scope=copy.deepcopy(data);del missing_scope['scope'];check('valid legacy result without scope accepted',evaluation.validate_result(missing_scope).status.value=='DONE')
    broken=LOCAL/'broken.json';broken.write_text('broken JSON',encoding='utf-8')
    with patch.dict(os.environ,EVALUATION_RESULT_PATH=str(broken)):
        failed=client.get('/api/v1/evaluation/latest').json();check('corrupt summary FAILED without scores',failed['status']=='FAILED' and failed['metrics'] is None)
    zero=evaluation.scores({'tp':0,'fp':0,'fn':0});check('zero denominator never 100 percent',zero=={'precision':None,'recall':None,'f1':None})
result={'commit':'e82465b2824fedca30b26a29427b6157ba7cfeb4','mode':'isolated local FastAPI HTTP using newly produced predictions; no production publish or OCR','checks':checks,'failed':[c for c in checks if not c['passed']]}
(OUT/'evaluation-e82465b-api-acceptance.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'failed':result['failed']},ensure_ascii=False))
