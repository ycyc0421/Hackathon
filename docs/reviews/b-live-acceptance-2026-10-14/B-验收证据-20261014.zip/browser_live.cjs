const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('D:/hackson/tmp/followup-browser-tools/node_modules/playwright');
const out=__dirname,repo='D:/hackson/tmp/acceptance-main-20261014',origin='https://hackathon.ychome.net';
fs.mkdirSync(path.join(out,'browser'),{recursive:true});
const checks=[],errors=[],tasks=[],pending=[];
const save=(name,obj)=>fs.writeFileSync(path.join(out,'browser',name),JSON.stringify(obj,null,2)+'\n');
const check=(name,passed,actual)=>checks.push({name,passed:!!passed,actual});
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
(async()=>{
 const browser=await chromium.launch({headless:true});
 const context=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true});
 const page=await context.newPage();page.setDefaultTimeout(25000);page.setDefaultNavigationTimeout(45000);
 page.on('pageerror',e=>errors.push(e.message));
 page.on('response',r=>{
  if(new URL(r.url()).pathname.match(/^\/api\/v1\/checks\/tsk_[^/]+$/)&&r.request().method()==='GET')pending.push((async()=>{try{const body=await r.json();if(['COMPLETED','PARTIAL','FAILED'].includes(body.status))tasks.push(body);}catch{}})());
 });
 try{
  await page.goto(origin+'/?mock=0#/upload',{waitUntil:'networkidle'});
  await page.locator('input[type=file]').waitFor({state:'attached'});
  const folder=path.join(repo,'backend/samples/04_de_multiitem');
  const sources=fs.readdirSync(folder).filter(f=>f.endsWith('.pdf')).map(f=>({name:f,mimeType:'application/pdf',buffer:fs.readFileSync(path.join(folder,f))}));
  await page.locator('input[type=file]').setInputFiles(sources);
  await page.getByRole('button',{name:'开始检查',exact:true}).click();
  for(let i=0;i<90&&!tasks.length;i++)await page.waitForTimeout(1000);
  if(!tasks.length)throw new Error('No real terminal task after browser upload');
  const task=tasks.at(-1);save('uploaded-task.json',task);
  check('real browser multipart completes',task.status==='COMPLETED',task.task_id);
  check('four SKUs survive frontend upload',task.items.length===4,task.items.length);
  await page.getByRole('button',{name:'差异',exact:true}).first().click();
  await page.getByRole('heading',{name:'差异比对',exact:true}).waitFor();
  await page.locator('.filter-row button').filter({hasText:'全部'}).click();
  await page.getByRole('button',{name:'对照',exact:true}).first().click();
  await page.getByRole('button',{name:/^查看原文/}).first().click();
  const drawer=page.getByRole('dialog');await drawer.waitFor();
  check('source drawer is single instance',await drawer.count()===1);
  check('drawer focus is close button',await page.getByRole('button',{name:'关闭原文预览',exact:true}).evaluate(e=>document.activeElement===e));
  const filename=await drawer.locator('.source-drawer-name').textContent();
  const frame=drawer.locator('iframe');check('PDF original opened at source page',await frame.count()===1&&(await frame.getAttribute('src')).includes('#page=1'));
  const [download]=await Promise.all([page.waitForEvent('download'),drawer.getByRole('button',{name:'下载原件',exact:true}).click()]);
  const target=path.join(out,'browser','original.pdf');await download.saveAs(target);
  check('drawer download exact original SHA256',digest(fs.readFileSync(target))===digest(fs.readFileSync(path.join(folder,filename))),filename);
  await page.screenshot({path:path.join(out,'browser','original-drawer.png'),fullPage:true});
  await page.getByRole('button',{name:'关闭原文预览',exact:true}).press('Escape');await drawer.waitFor({state:'hidden'});check('Escape closes drawer',true);
  await page.getByRole('button',{name:'报告',exact:true}).first().click();
  await page.getByRole('button',{name:'导出 HTML 报告',exact:true}).waitFor();
  const [html]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'导出 HTML 报告',exact:true}).click()]);
  const hp=path.join(out,'browser','report.html');await html.saveAs(hp);const ht=fs.readFileSync(hp,'utf8');
  check('frontend HTML report real task and warning',ht.includes(task.task_id)&&(/未经核实|未核实|未验证/.test(ht)),{bytes:Buffer.byteLength(ht),hasTask:ht.includes(task.task_id)});
  const [archive]=await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'导出归档 JSON',exact:true}).click()]);
  const ap=path.join(out,'browser','archive.json');await archive.saveAs(ap);const ar=JSON.parse(fs.readFileSync(ap));
  check('archive retains full extraction',ar.task?.task_id===task.task_id&&ar.task.extractions.length===3);
  await page.reload({waitUntil:'networkidle'});await page.getByRole('button',{name:'导出 HTML 报告',exact:true}).waitFor();
  check('refresh restores same public task',page.url().includes('task='+task.task_id)&&(await page.locator('body').innerText()).includes(task.task_id));
  await page.getByRole('button',{name:'差异',exact:true}).first().click();await page.getByRole('heading',{name:'差异比对',exact:true}).waitFor();
  await page.locator('.filter-row button').filter({hasText:'全部'}).click();await page.getByRole('button',{name:'对照',exact:true}).first().click();
  const restoredSources=await page.getByRole('button',{name:/^查看原文/}).count();
  check('original preview entry after refresh',restoredSources>0,restoredSources);
  if(restoredSources){await page.getByRole('button',{name:/^查看原文/}).first().click();await drawer.waitFor();check('original fetched after refresh',await drawer.locator('iframe').count()===1);await page.getByRole('button',{name:'关闭原文预览',exact:true}).click();}
  await page.setViewportSize({width:390,height:844});await page.waitForTimeout(600);
  const widths=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}));check('390px diff no horizontal overflow',widths.document<=widths.viewport,widths);
  await page.screenshot({path:path.join(out,'browser','diff-mobile.png'),fullPage:true});
  await page.getByRole('button',{name:'评测',exact:true}).first().click();await page.waitForTimeout(600);const evalText=await page.locator('body').innerText();
  check('unrun evaluation shown without fabricated score',/尚未|未运行|未执行|未跑|暂无/.test(evalText),evalText.slice(-1800));
  await page.screenshot({path:path.join(out,'browser','evaluation-mobile.png'),fullPage:true});
 }catch(e){check('browser flow completed',false,{kind:e.name,message:e.message});await page.screenshot({path:path.join(out,'browser','failure.png'),fullPage:true}).catch(()=>{});}
 finally{await Promise.allSettled(pending);check('no unhandled page errors',errors.length===0,errors);save('checks.json',checks);save('summary.json',{mode:'real headless Chromium to public deployed site; no API mocking',checks:checks.length,failed:checks.filter(x=>!x.passed),tasks:[...new Set(tasks.map(t=>t.task_id))],page_errors:errors,limits:['PDF native reader content not text-extracted from iframe','No full accessibility/design audit','No production restart test']});console.log(JSON.stringify({checks:checks.length,failed:checks.filter(x=>!x.passed),tasks:[...new Set(tasks.map(t=>t.task_id))],page_errors:errors}));await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
