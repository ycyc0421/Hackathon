import hashlib,json,time
from pathlib import Path
import httpx
OUT=Path(__file__).resolve().parent;ORIGIN='https://hackathon.ychome.net';SHA='e82465b2824fedca30b26a29427b6157ba7cfeb4'
DATA=Path('D:/hackson/ocr-local/inputs/trade_documents_hackathon_v2/trade_documents_hackathon_v2')
def save(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks=[]
def check(n,p,a=None):checks.append(dict(name=n,passed=bool(p),actual=a))
with httpx.Client(timeout=60,headers={'User-Agent':'Hackathon-B-readonly-diagnostic','Accept':'application/json','Origin':ORIGIN}) as c:
    def get(p):r=c.get(ORIGIN+p);r.raise_for_status();return r.json()
    health=get('/health');save('meta/health-new-start.json',health);check('latest deployed SHA',health.get('release_revision')==SHA,health)
    if health.get('release_revision')!=SHA:
        save('latest-live-acceptance.json',{'checks':checks,'outcome':'latest revision not yet deployed'});raise SystemExit(2)
    evaluation=get('/api/v1/evaluation/latest');save('meta/evaluation-new.json',evaluation)
    runs=get('/api/v1/evaluation/runs');save('meta/evaluation-runs-new.json',runs)
    check('evaluation history available',isinstance(runs,list),len(runs))
    check('evaluation state truthful',evaluation['status'] in ['DONE','NOT_RUN'],evaluation['status'])
    if evaluation['status']=='DONE':
        check('evaluation scope preserved',bool(evaluation.get('scope')),evaluation.get('scope'))
        for name,count in evaluation.get('scope',{}).get('counts',{}).items():
            if name not in evaluation['metrics']:continue
            tp,fp,fn=[count[k] for k in ['tp','fp','fn']];expected={'precision':tp/(tp+fp) if tp+fp else None,'recall':tp/(tp+fn) if tp+fn else None,'f1':2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else None}
            check('live score arithmetic '+name,all(evaluation['metrics'][name].get(k)==v for k,v in expected.items()),expected)
    for name in ['shirt-originals','ocr_png','ocr_scan','corrected']:
        source=json.loads((OUT/'tasks'/f'{name}.json').read_text(encoding='utf-8'));task=get('/api/v1/checks/'+source['task_id'])
        check('old task persists through deployment '+name,task==source)
        if name=='ocr_png':
            manifest=next(m for m in json.loads((OUT/'input-manifest.json').read_text(encoding='utf-8')) if m['case']==name)
            for doc in task['documents']:
                r=c.get(ORIGIN+'/api/v1/checks/'+task['task_id']+'/files/'+doc['file_id']);expected=next(e['sha256'] for e in manifest['files'] if e['name']==doc['file_name'])
                check('PNG original survives deployment '+doc['file_name'],r.is_success and hashlib.sha256(r.content).hexdigest()==expected)
    paths=[DATA/'backend/samples/SHP-00093'/name for name in ['commercial_invoice.pdf','packing_list.pdf','proforma_invoice.pdf']]
    files=[('files',(p.name,p.read_bytes(),'application/pdf')) for p in paths]
    r=c.post(ORIGIN+'/api/v1/checks',files=files,data={'destination_country':'GB','notes':'B 新主分支验收：合成样例SHP-00093，验证已知地址比较缺口，不作为真实业务单证'});r.raise_for_status();tid=r.json()['task_id']
    for _ in range(60):
        t=get('/api/v1/checks/'+tid)
        if t['status'] not in ['PENDING','PROCESSING']:break
        time.sleep(1)
    save('latest-address-task.json',t);check('address regression uses text not OCR',all(e['parse_method']=='TEXT_LAYER' for e in t['extractions']))
    check('address conflict detected (current capability gap)',any(x['field_key']=='consignee_address' and x['status']=='CONFLICT' for x in t['comparisons']),{'task_id':tid,'status':t['status'],'conflict_count':t['summary']['conflict_count'],'address_fields':[f for e in t['extractions'] for f in e['fields'] if f['field_key']=='consignee_address']})
    save('meta/health-new-end.json',get('/health'))
save('latest-live-acceptance.json',{'commit':SHA,'mode':'live latest-revision GET, one synthetic text regression; previous OCR tasks retained, not re-run','checks':checks,'failed':[x for x in checks if not x['passed']],'address_task':tid})
print(json.dumps({'checks':len(checks),'failed':[x for x in checks if not x['passed']],'live_evaluation':{'status':evaluation['status'],'sample_count':evaluation['sample_count'],'scope':evaluation.get('scope')},'address_task':tid},ensure_ascii=False))
