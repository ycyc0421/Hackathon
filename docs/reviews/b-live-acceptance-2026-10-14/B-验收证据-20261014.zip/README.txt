材料为B独立验收，具体版本/边界见验收反馈.txt。输入和预测未修改。
inputs/含本轮12个线上任务输入；dataset/是原数据包test文本划分15票及原始完整元信息，不包含其他划分原件，不是完整100票包。
复现评测：检出e82465b2824fedca30b26a29427b6157ba7cfeb4，安装backend/requirements.txt，运行：
python backend/tools/evaluate_dataset.py --dataset <本包dataset目录> --out <新的空目录> --split test --input-kind text
会独立上传原文本到本地FastAPI，关闭OCR和通用LLM。金标不作为模型输入。对照已保存evaluation-e82465b-test-text-run3目录。
线上任务GET与原件URL可从tasks/的task_id/file_id重建。请勿将本地新预测当作生产模型新推理。
脚本中的D盘路径是B本机环境，复用在线验收脚本需调整根目录；无密码、Token、模型权重、运行数据库或认证请求头。
