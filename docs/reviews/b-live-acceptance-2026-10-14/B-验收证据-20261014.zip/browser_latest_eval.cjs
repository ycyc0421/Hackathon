const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('D:/hackson/tmp/followup-browser-tools/node_modules/playwright');
const out=__dirname,checks=[],errors=[];
const check=(name,passed,actual)=>checks.push({name,passed:!!passed,actual});
(async()=>{const b=await chromium.launch({headless:true});const p=await b.newPage({viewport:{width:1440,height:1000}});p.on('pageerror',e=>errors.push(e.message));try{
 await p.goto('https://hackathon.ychome.net/?mock=0#/eval',{waitUntil:'networkidle'});await p.getByText('本次评测信息',{exact:true}).waitFor();
 const body=await p.locator('body').innerText();const expected=JSON.parse(fs.readFileSync(path.join(out,'meta/evaluation-new.json')));
 check('DONE evaluation shown',body.includes(expected.model_version)&&body.includes(expected.dataset_version));
 check('dataset/channel/split/limitations visible',body.includes(expected.scope.dataset_kind)&&body.includes(expected.scope.input_kind)&&expected.scope.limitations.some(s=>body.includes(s)),{scope_kind_present:body.includes(expected.scope.dataset_kind),input_kind_present:body.includes(expected.scope.input_kind),limitations_present:expected.scope.limitations.some(s=>body.includes(s))});
 check('history selection available',(await p.locator('select,[role=combobox]').count())>0||(await p.getByText(/历史评测|评测历史|选择.*评测/).count())>0);
 await p.screenshot({path:path.join(out,'browser/latest-evaluation-desktop.png'),fullPage:true});
 fs.writeFileSync(path.join(out,'browser/latest-evaluation-text.txt'),body,'utf8');
}catch(e){check('latest evaluation UI flow',false,{kind:e.name,message:e.message});}finally{check('no unhandled page errors',errors.length===0,errors);fs.writeFileSync(path.join(out,'browser/latest-evaluation-checks.json'),JSON.stringify({checks,failed:checks.filter(c=>!c.passed),page_errors:errors,mode:'live new main evaluation; no mock'},null,2));console.log(JSON.stringify({checks:checks.length,failed:checks.filter(c=>!c.passed),page_errors:errors}));await b.close();}})();
