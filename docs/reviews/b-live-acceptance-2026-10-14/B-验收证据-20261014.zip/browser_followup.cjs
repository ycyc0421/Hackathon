const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('D:/hackson/tmp/followup-browser-tools/node_modules/playwright');
const out=__dirname,origin='https://hackathon.ychome.net',checks=[],errors=[],requests=[];
const check=(name,passed,actual)=>checks.push({name,passed:!!passed,actual});
(async()=>{
 const browser=await chromium.launch({headless:true});const context=await browser.newContext({viewport:{width:1440,height:1000}});const page=await context.newPage();page.setDefaultTimeout(25000);
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/api/v1'))requests.push({method:r.method(),path:new URL(r.url()).pathname});});
 try{
  const task=JSON.parse(fs.readFileSync(path.join(out,'browser/uploaded-task.json')));
  await page.goto(origin+'/?mock=0&task='+task.task_id+'#/report',{waitUntil:'networkidle'});
  await page.getByRole('button',{name:'导出 HTML 报告',exact:true}).waitFor();
  await page.getByRole('button',{name:'差异',exact:true}).first().click();await page.getByRole('heading',{name:'差异比对',exact:true}).waitFor();
  await page.locator('.filter-row button').filter({hasText:'全部'}).click();await page.getByRole('button',{name:'对照',exact:true}).first().click();await page.waitForTimeout(500);
  const count=await page.getByRole('button',{name:/^查看原文/}).count();check('refresh restores original preview entry',count>0,{preview_buttons:count,backend_original_endpoint:'GET /api/v1/checks/'+task.task_id+'/files/{file_id}',original_fetch_requests:requests.filter(r=>r.path.includes('/files/'))});
  await page.screenshot({path:path.join(out,'browser/refreshed-diff-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});await page.waitForTimeout(600);const widths=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}));check('390px diff no horizontal overflow',widths.document<=widths.viewport,widths);await page.screenshot({path:path.join(out,'browser/diff-mobile.png'),fullPage:true});
  await page.getByRole('button',{name:'评测',exact:true}).first().click();await page.getByText('尚未评测',{exact:true}).waitFor();check('NOT_RUN shows no invented score',true);await page.screenshot({path:path.join(out,'browser/evaluation-mobile.png'),fullPage:true});
  for(const [name,status] of [['edi-only','FAILED'],['mixed-pdf-edi','PARTIAL']]){
   const t=JSON.parse(fs.readFileSync(path.join(out,'tasks/'+name+'.json')));
   await page.goto(origin+'/?mock=0&task='+t.task_id+'#/report',{waitUntil:'networkidle'});await page.getByRole('button',{name:'导出 HTML 报告',exact:true}).waitFor();const text=await page.locator('body').innerText();
   check(name+' report preserves unsuccessful outcome',status==='FAILED'?text.includes('检查失败'):text.includes('不完整'),text.slice(-1300));
   check(name+' failed report remains downloadable',await page.getByRole('button',{name:'导出归档 JSON',exact:true}).isEnabled());
   await page.screenshot({path:path.join(out,'browser/'+name+'-mobile.png'),fullPage:true});
  }
 }catch(e){check('remaining browser flow completed',false,{kind:e.name,message:e.message});}
 finally{check('no unhandled page errors',errors.length===0,errors);fs.writeFileSync(path.join(out,'browser/followup.json'),JSON.stringify({checks,failed:checks.filter(c=>!c.passed),requests,page_errors:errors,mode:'real live browser; restored previously created tasks, no new uploads'},null,2));console.log(JSON.stringify({checks:checks.length,failed:checks.filter(c=>!c.passed),page_errors:errors}));await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
