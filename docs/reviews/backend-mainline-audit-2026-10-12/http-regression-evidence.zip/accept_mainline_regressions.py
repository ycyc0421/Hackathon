import copy,json,sys
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
sys.path.insert(0,'backend')
from app import main
from app.pipeline import runner
from app.sqlite_store import TaskStore
from app.workflow import payload_hash
from fastapi.testclient import TestClient
out=Path('backend/.out/mainline-acceptance')
out.mkdir(exist_ok=True)
results={}
with TemporaryDirectory(dir=out) as directory:
    store=TaskStore(Path(directory)/'tasks.db',Path(directory)/'legacy')
    with patch.object(main,'store',store),patch.object(runner,'store',store),patch.object(runner,'UPLOAD_DIR',Path(directory)/'uploads'),TestClient(main.app) as client:
        def revise(task,changes,request_id):
            response=client.post('/api/v1/checks/'+task['task_id']+'/corrections',json={
                'request_id':request_id,'source_hash':payload_hash(task),
                'reason':'隔离回归：按保存原件证据复核','changes':changes})
            response.raise_for_status()
            results[request_id]=response.json()
            return store.get(response.json()['task_id'])
        original=json.loads(Path('backend/.out/shirt/http-result.json').read_text(encoding='utf-8'))['task']
        store.create(original)
        child=revise(original,[{'file_id':'f1','field_key':'currency','value':'USD'}],'unrelated-currency')
        assert next(c for c in child['comparisons'] if c.get('item_id') and c['field_key']=='description')['status']=='NOT_CHECKED'
        for file_id in ('f1','f2'):
            child=revise(child,[{'file_id':file_id,'item_no':1,'field_key':'description',
                                 'value':'100% Cotton T-shirt, unisex, assorted colors'}],'review-'+file_id)
        assert next(c for c in child['comparisons'] if c.get('item_id') and c['field_key']=='description')['status']=='MATCH'
        assert not any(e['code']=='OCR_TEXT_DISAGREEMENT' for e in child['errors'])
        assert store.get(original['task_id'])==original
        from fpdf import FPDF
        pdf=FPDF()
        for text in ['COMMERCIAL INVOICE\nDocument No.: CI-PAGE-1\nCurrency: USD\nNO.   SKU   DESCRIPTION   QTY\n1   A1   MUG   10 PCS',
                     'COMMERCIAL INVOICE\nCurrency: USD\nNO.   SKU   DESCRIPTION   QTY\n1   B2   BOWL   20 PCS\nTOTAL AMOUNT (USD): 80.00']:
            pdf.add_page()
            pdf.set_font('Courier',size=10)
            for line in text.splitlines():
                pdf.cell(0,6,line,new_x='LMARGIN',new_y='NEXT')
        response=client.post('/api/v1/checks',data={'destination_country':'US'},files=[('files',('controlled-multipage.pdf',bytes(pdf.output()),'application/pdf'))])
        response.raise_for_status()
        task_id=response.json()['task_id']
        import time
        deadline=time.monotonic()+15
        while store.get(task_id)['status'] in {'PENDING','PROCESSING'} and time.monotonic()<deadline:
            time.sleep(.1)
        task=store.get(task_id)
        assert task['status']=='COMPLETED',task['errors']
        fields={f['field_key']:f for f in task['extractions'][0]['fields']}
        assert fields['document_no']['page']==1,fields['document_no']
        assert fields['total_amount']['page']==2,fields['total_amount']
        assert fields['currency']['page'] is None,fields['currency']
        assert [next(f['page'] for f in row['fields'] if f['field_key']=='quantity') for row in task['extractions'][0]['line_items']]==[1,2]
        results['controlled-multipage']=client.get('/api/v1/checks/'+task_id).json()
        original=json.loads(Path('backend/.out/followup-fixed/SHP-00015.json').read_text(encoding='utf-8'))['task']
        store.create(original)
        assert any(e['code']=='LINE_AMOUNT_MISMATCH' for e in original['errors'])
        child=revise(original,[{'file_id':'f1','item_no':1,'field_key':'amount','value':'1870.00'}],'review-amount')
        assert not any(e['code']=='LINE_AMOUNT_MISMATCH' for e in child['errors'])
        assert store.get(original['task_id'])==original
(out/'mainline-http-regressions.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print('HTTP regressions passed: pending OCR, explicit review, stale arithmetic, immutable originals')
