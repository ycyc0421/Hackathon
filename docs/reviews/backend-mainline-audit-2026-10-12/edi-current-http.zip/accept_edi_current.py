import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'backend/tools')
from test_file_access import FileAccessTests
from app.frontend_view import to_frontend_task
case=FileAccessTests();case.setUp()
root=Path('backend/.out/edi-bundle/backend/samples/edi');out=Path('backend/.out/edi-http');out.mkdir(exist_ok=True)
records=[]
try:
 for path in sorted(root.rglob('*.edi')):
  data=path.read_bytes();task=case.upload(path.name,data)
  public=case.client.get('/api/v1/checks/'+task['task_id']).json()
  response=case.client.get('/api/v1/checks/'+task['task_id']+'/files/f1')
  assert response.status_code==200 and response.content==data
  assert task['status']=='FAILED' and task['documents'][0]['process_status']=='UNSUPPORTED'
  name=path.relative_to(root).as_posix();record={'input':name,'sha256':hashlib.sha256(data).hexdigest(),'task_status':task['status'],'file_status':'UNSUPPORTED','download_bytes_verified':True,'parsing_acceptance':'BLOCKED_PARSER_NOT_INTEGRATED'}
  records.append(record);(out/(name.replace('/','__')+'.json')).write_text(json.dumps(public,ensure_ascii=False,indent=2),encoding='utf-8')
finally:case.tearDown()
(out/'summary.txt').write_text(json.dumps({'input_commit':'9b2896d68af4f2a20640efc0a762a4903806104d','files':len(records),'http_source_and_failure_checks':'PASSED','edi_parsing_acceptance':'BLOCKED','records':records},ensure_ascii=False,indent=2),encoding='utf-8')
assert len(records)==23
print('23 originals: honest UNSUPPORTED/FAILED and byte-identical download verified; parser acceptance BLOCKED')
