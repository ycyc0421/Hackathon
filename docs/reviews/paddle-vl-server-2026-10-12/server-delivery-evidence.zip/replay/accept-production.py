import hashlib
import json
from pathlib import Path
import subprocess
import re
import time
import httpx

root = Path.home()/'app'
release = root/'current'
out = root/'validation/paddle-vl-main/final/backend/.out/production-final'
out.mkdir(parents=True, exist_ok=True)
base = 'https://hackathon.ychome.net'
checks = []
def check(label, actual, expected=True):
    checks.append({'check':label, 'actual':actual, 'expected':expected, 'passed':actual==expected})

with httpx.Client(base_url=base, timeout=60, trust_env=False) as client:
    health = client.get('/health');health.raise_for_status()
    check('exact deployed revision', health.json().get('release_revision'), '831e90f5b7c98f7f39ba86e52161fd75cc8564e2')
    capabilities = client.get('/api/v1/capabilities').json()
    (out/'capabilities.json').write_text(json.dumps(capabilities,ensure_ascii=False,indent=2))
    # Run the established text and static-site smoke through the public reverse proxy.
    import sys
    sys.path.insert(0,str(release/'deploy'))
    from smoke import run
    import os
    os.chdir(release)
    run(base+'/api/v1',base,out/'text-smoke',ocr_enabled=False)
    samples=release/'backend/samples/shirt-originals'
    names=['exportdoc-proforma-invoice-sample.pdf','exportdoc-commercial-invoice-sample.pdf','exportdoc-packing-list-sample.pdf']
    originals=[(name,(samples/name).read_bytes()) for name in names]
    created=client.post('/api/v1/checks',data={'destination_country':'US','notes':'F final production acceptance: original DEMO samples'},files=[('files',(name,data,'application/pdf')) for name,data in originals])
    created.raise_for_status()
    task_id=created.json()['task_id']
    for _ in range(900):
        task=client.get('/api/v1/checks/'+task_id).json()
        if task['status'] not in {'PENDING','PROCESSING'}:break
        time.sleep(1)
    check('three originals completed',task['status'],'COMPLETED')
    check('all three documents extracted',len(task['documents'])==3 and all(doc['process_status']=='EXTRACTED' for doc in task['documents']))
    for index in range(1,4):
        extraction=next(ext for ext in task['extractions'] if ext['file_id']==f'f{index}')
        fields=extraction['fields']
        def field(key,line=None):
            found=[value for value in fields if value['field_key']==key and value.get('line_no')==line]
            return found[0] if len(found)==1 else {}
        check(f'f{index} own document number',field('document_no').get('normalized_value'),['PI','CI','PL'][index-1]+'-20260830-08300186')
        compact=lambda value:re.sub(r'[^a-z0-9]','',str(value or '').casefold())
        check(f'f{index} seller',compact(field('shipper').get('normalized_value')),compact('Ningbo Qihang Export Co., Ltd.'))
        check(f'f{index} buyer',compact(field('consignee').get('normalized_value')),compact('Global Fashion Inc.'))
        check(f'f{index} quantity',field('quantity',1).get('normalized_value'),500)
        check(f'f{index} source page',field('quantity',1).get('page'),1)
        check(f'f{index} source region',bool(field('quantity',1).get('bbox')))
        if index<3:
            check(f'f{index} line amount',field('amount',1).get('normalized_value'),1400)
            check(f'f{index} unit price',field('unit_price',1).get('normalized_value'),2.8)
        else:
            for key,value in [('packages',20),('net_weight',150),('gross_weight',170),('volume',1.68)]:
                check('PL '+key,field(key,1).get('normalized_value'),value)
            check('PL generic packaging unit remains unknown',field('packages',1).get('unit'),None)
            check('PL no fabricated total',field('total_amount').get('normalized_value'),None)
            check('PL no fabricated line amount',field('amount',1).get('normalized_value'),None)
        downloaded=client.get(f'/api/v1/checks/{task_id}/files/f{index}')
        check(f'f{index} original bytes preserved',downloaded.is_success and downloaded.content==originals[index-1][1])
    (out/'shirt-public.json').write_text(json.dumps(task,ensure_ascii=False,indent=2))
    report=client.get(f'/api/v1/checks/{task_id}/report');report.raise_for_status()
    (out/'report.json').write_text(json.dumps(report.json(),ensure_ascii=False,indent=2))
    html=client.get(f'/api/v1/checks/{task_id}/report?format=html')
    check('HTML export',html.is_success and 'text/html' in html.headers.get('content-type',''))
    context=client.get(f'/api/v1/checks/{task_id}/corrections');context.raise_for_status()
    body={'source_hash':context.json()['result_hash'],'request_id':'production-final-unit-price-v1','reason':'F acceptance correction on DEMO sample','changes':[{'file_id':'f2','field_key':'unit_price','item_no':1,'value':'3.0'}]}
    corrected=client.post(f'/api/v1/checks/{task_id}/corrections',json=body)
    corrected.raise_for_status()
    child=corrected.json()
    check('correction creates child',child['task_id']!=task_id)
    check('arithmetic warning recomputed',any(error['code']=='LINE_AMOUNT_MISMATCH' for error in child['errors']))
    replay=client.post(f'/api/v1/checks/{task_id}/corrections',json=body)
    check('correction retry idempotent',replay.is_success and replay.json()['task_id']==child['task_id'])
    (out/'corrected-public.json').write_text(json.dumps(child,ensure_ascii=False,indent=2))
    subprocess.run(['systemctl','--user','restart','hackathon-backend.service'],check=True)
    for _ in range(60):
        try:
            if client.get('/health').is_success:break
        except httpx.HTTPError:pass
        time.sleep(1)
    check('completed task exact after actual API restart',client.get('/api/v1/checks/'+task_id).json(),task)
    check('derived task exact after actual API restart',client.get('/api/v1/checks/'+child['task_id']).json(),child)
    summary={'status':'PASSED' if all(item['passed'] for item in checks) else 'FAILED','base_url':base,'release':release.resolve().name,'checks':checks}
    (out/'acceptance.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({'status':summary['status'],'checks':len(checks),'failed':[item['check'] for item in checks if not item['passed']]}),flush=True)
