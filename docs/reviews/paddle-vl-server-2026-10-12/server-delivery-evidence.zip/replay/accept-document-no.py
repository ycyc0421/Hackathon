import json
from pathlib import Path
import httpx

root=Path.home()/'app/validation/paddle-vl-main'
out=root/'final/backend/.out/production-final'
parent=json.loads((out/'shirt-public.json').read_text())
task_id=parent['task_id']
checks=[]
def check(label,value):checks.append({'check':label,'passed':bool(value)})
with httpx.Client(base_url='https://hackathon.ychome.net',timeout=60,trust_env=False) as client:
    context=client.get(f'/api/v1/checks/{task_id}/corrections');context.raise_for_status()
    body={'source_hash':context.json()['result_hash'],'request_id':'production-final-document-no-v1','reason':'F4 DEMO document number correction acceptance','changes':[{'file_id':'f2','field_key':'document_no','value':'CI-DEMO-CORRECTED'}]}
    result=client.post(f'/api/v1/checks/{task_id}/corrections',json=body);result.raise_for_status()
    child=result.json()
    ext=next(item for item in child['extractions'] if item['file_id']=='f2')
    value=next(item for item in ext['fields'] if item['field_key']=='document_no' and item.get('line_no') is None)
    check('document_no correction accepted',value['normalized_value']=='CI-DEMO-CORRECTED')
    check('original task unchanged',client.get(f'/api/v1/checks/{task_id}').json()==parent)
    replay=client.post(f'/api/v1/checks/{task_id}/corrections',json=body)
    check('document_no correction idempotent',replay.is_success and replay.json()['task_id']==child['task_id'])
    for index,name in enumerate(['exportdoc-proforma-invoice-sample.pdf','exportdoc-commercial-invoice-sample.pdf','exportdoc-packing-list-sample.pdf'],1):
        downloaded=client.get(f'/api/v1/checks/{child["task_id"]}/files/f{index}')
        expected=(Path.home()/'app/current/backend/samples/shirt-originals'/name).read_bytes()
        check(f'corrected f{index} original bytes',downloaded.is_success and downloaded.content==expected)
    (out/'document-no-public.json').write_text(json.dumps(child,ensure_ascii=False,indent=2))
summary={'status':'PASSED' if all(item['passed'] for item in checks) else 'FAILED','checks':checks}
(out/'document-no-acceptance.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary))
