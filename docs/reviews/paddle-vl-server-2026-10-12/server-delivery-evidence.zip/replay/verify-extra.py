import csv
import json
from pathlib import Path
import time
import httpx

root = Path('<deploy-home>/app/validation/paddle-vl-main')
final = root/'final'
out = final/'backend/.out/extra-final'
out.mkdir(parents=True, exist_ok=True)
checks = []
for path in (final/'backend/.out/b-digital-final/public').glob('SHP-*.json'):
    task = json.loads(path.read_text())
    for extraction in task['extractions']:
        for field in extraction['fields']:
            raw = str(field.get('raw_value') or '').casefold()
            if field['field_key'] == 'destination_country' and ('australia' in raw or 'singapore' in raw):
                expected = 'AU' if 'australia' in raw else 'SG'
                checks.append({'case': path.stem, 'file': extraction['file_id'], 'raw': field['raw_value'], 'expected': expected, 'actual': field['normalized_value'], 'passed': field['normalized_value'] == expected and field['status'] == 'EXTRACTED'})
assert len(checks) == 126, len(checks)
(out/'country-checks.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2))
assert all(check['passed'] for check in checks)
dataset = root/'b-evidence/inputs/dataset'
records = list(csv.DictReader((dataset/'dataset_manifest.csv').open(encoding='utf-8-sig')))
records = [record for record in records if record['shipment_group_id'] == 'SHP-00001' and record['document_id'].endswith('_scan_png')]
with httpx.Client(base_url='http://127.0.0.1:18081', timeout=60, trust_env=False) as client:
    for _ in range(120):
        if not httpx.get('http://127.0.0.1:18082/health').json()['busy']:
            break
        time.sleep(1)
    response = client.post('/api/v1/checks', data={'destination_country': 'US'}, files=[('files', (Path(record['local_path']).name, (dataset/record['local_path']).read_bytes(), 'image/png')) for record in records])
    response.raise_for_status()
    task_id = response.json()['task_id']
    for _ in range(1800):
        task = client.get('/api/v1/checks/'+task_id).json()
        if task['status'] not in {'PENDING', 'PROCESSING'}:
            break
        time.sleep(1)
    (out/'scan-public.json').write_text(json.dumps(task, ensure_ascii=False, indent=2))
    (out/'scan-report.json').write_text(json.dumps(client.get('/api/v1/checks/'+task_id+'/report').json(), ensure_ascii=False, indent=2))
    scan_checks = []
    for record in records:
        golden = json.loads((dataset/record['extraction_path']).read_text())
        document = next(doc for doc in task['documents'] if doc['file_name'] == Path(record['local_path']).name)
        extraction = next((ext for ext in task['extractions'] if ext['file_id'] == document['file_id']), {})
        fields = extraction.get('fields', [])
        scan_checks.append({'check': document['file_name']+' extracted', 'passed': document['process_status'] == 'EXTRACTED'})
        for expected in golden['fields']:
            if expected['field_key'] not in {'shipper', 'consignee', 'item_code', 'quantity', 'unit_price', 'amount', 'total_amount', 'packages', 'net_weight', 'gross_weight', 'volume'}:
                continue
            if expected['normalized_value'] is None:
                continue
            found = [field for field in fields if field['field_key'] == expected['field_key'] and field.get('line_no') == expected.get('line_no')]
            actual = found[0] if len(found) == 1 else {}
            value = actual.get('normalized_value')
            same = value == expected['normalized_value']
            if expected['field_key'] in {'shipper', 'consignee'}:
                import re
                clean = lambda text: re.sub(r'[^a-z0-9]', '', str(text).casefold())
                same = clean(value) == clean(expected['normalized_value'])
            scan_checks.append({'check': document['file_name']+'/'+expected['field_key']+'/'+str(expected.get('line_no')), 'expected': expected['normalized_value'], 'actual': value, 'passed': same and actual.get('page') == 1})
    summary = {'country_checks': len(checks), 'country_passed': all(check['passed'] for check in checks), 'scan_status': task['status'], 'scan_checks': scan_checks}
    (out/'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(json.dumps(summary, ensure_ascii=False), flush=True)
