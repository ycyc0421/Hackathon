"""Make a reproducible evidence packet without models, databases, credentials, or application edits."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root=Path(__file__).resolve().parent
source=Path(r'D:\hackson\tmp\review37-fca14f5-20261012')
dataset=Path(r'D:\hackson\ocr-local\inputs\trade_documents_hackathon_v2\trade_documents_hackathon_v2')
edi=Path(r'D:\hackson\tmp\issue40-edi-publication\backend\samples\edi')
pin='fca14f56910333c4bac8c72cfd6428ffe2fb6f2a'
packet=root/'delivery'; packet.mkdir(exist_ok=True)
validation=root/'validation-public';validation.mkdir(exist_ok=True)

def copy(origin,target):
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,target)

validation_sources={}
for stage in ['digital','ocr-default','ocr-py312-default']:
    for path in (root/stage/'public').glob('*.json'):
        name=stage+'__'+path.name;copy(path,validation/name);validation_sources[name]=str(path.relative_to(root))
for stage in ['workflow-ocr','workflow-arithmetic']:
    for path in (root/stage).glob('*-public.json'):
        name=stage+'__'+path.name;copy(path,validation/name);validation_sources[name]=str(path.relative_to(root))
copy(root/'interrupted-restart/after-public.json',validation/'interrupted-restart.json')
validation_sources['interrupted-restart.json']='interrupted-restart/after-public.json'
schema=subprocess.run(['node',str(source/'backend/tools/validate_outputs.mjs'),str(validation)],cwd=source,
                      stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
(root/'schema-validation-all.log').write_text(schema.stdout,encoding='utf-8')
if schema.returncode:raise RuntimeError('schema/cross-field checks failed; see schema-validation-all.log')
(root/'validation-index.json').write_text(json.dumps(validation_sources,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Preserve the incomplete diagnostic attempt; it was never a terminal extraction result.
incomplete={'source_commit':pin,'status':'INCOMPLETE','error_type':'httpx.RemoteProtocolError',
            'message':'Server disconnected without sending a response during GET polling',
            'server_exit_code_before_cleanup':'not recorded by first revision of harness',
            'limits':'Do not count as parsed, failed parsing, or a proven native crash. Later restart results are recorded separately.'}
(root/'ocr-diagnostic/execution-error.json').write_text(json.dumps(incomplete,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'ocr-testclient-diagnostic/execution-error.json').write_text(json.dumps({'source_commit':pin,'status':'INCOMPLETE',
    'error_type':'AssertionError','message':'Timed out: SHP-00001 after 300 seconds','evidence':'TestClient with fresh OCR and enable_mkldnn=False',
    'limits':'No terminal response recorded; this is not an accuracy result.'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Keep inputs and independent expectations portable, without regenerating a single original.
for group in sorted((dataset/'backend/samples').glob('SHP-*')):
    for path in group.glob('*.pdf'):
        if '.scan.' not in path.name:copy(path,packet/'inputs/dataset/backend/samples'/group.name/path.name)
for path in (dataset/'backend/samples/SHP-00001').glob('*.scan.png'):
    copy(path,packet/'inputs/dataset/backend/samples/SHP-00001'/path.name)
for name in ['dataset_manifest.csv','input_sha256.json','README.md','dataset_provenance.json']:
    if (dataset/name).is_file():copy(dataset/name,packet/'inputs/dataset'/name)
for path in (dataset/'docs/fixtures/raw').glob('*.json'):
    copy(path,packet/'inputs/dataset/docs/fixtures/raw'/path.name)
for path in (dataset/'docs/fixtures/result').glob('*.json'):
    copy(path,packet/'inputs/dataset/docs/fixtures/result'/path.name)
copy(dataset/'evaluation_only/gold.jsonl',packet/'inputs/dataset/evaluation_only/gold.jsonl')
for path in edi.rglob('*'):
    if path.is_file():copy(path,packet/'inputs/edi'/path.relative_to(edi))
for path in (source/'backend/samples/shirt-originals').iterdir():
    if path.is_file():copy(path,packet/'inputs/shirt-originals'/path.name)
for path in (source/'backend/samples/review38').glob('*.json'):
    copy(path,packet/'inputs/project-json'/path.name)
for name in ['review_latest.py','serve_candidate.py','analyze_originals.py','restart_interrupted.py','review_stored_workflow.py',
             'prepare_delivery.py','requirements-py312-ocr.lock.txt','requirements-py313-ocr.lock.txt','schema-validation-all.log','validation-index.json']:
    copy(root/name,packet/name)
copy(Path(r'D:\hackson\output\new-case-tests-20261012\run_package_cases.py'),packet/'legacy_testclient_probe.py')
for stage in ['digital','ocr-default','ocr-diagnostic','ocr-py312-default','ocr-testclient-diagnostic',
              'workflow-arithmetic','workflow-ocr','interrupted-restart']:
    for path in (root/stage).rglob('*'):
        if not path.is_file() or 'runtime' in path.relative_to(root/stage).parts:continue
        if path.suffix in {'.json','.txt','.md','.html','.log'}:
            copy(path,packet/'evidence'/stage/path.relative_to(root/stage))
for path in root.glob('test_*.py.log'):copy(path,packet/'evidence/unit'/path.name)

report='''后端最新版独立复验记录（2026-10-12）

结论：已覆盖的核心提取和比较修复有效；仍有目的国归一、处理中原件持久化/终态清单、包装单位语义等缺口，不判定业务整体验收通过。

固定版本：PR #37，fca14f56910333c4bac8c72cfd6428ffe2fb6f2a。开始与结束均核对远端仍为此 HEAD。
没有改应用源码、原始 PDF/图片/EDI、生产配置或部署。测试使用独立工作树、本机真实 TCP HTTP、独立 SQLite 和上传目录。

已验证事实
1. 完整100票、300份文本PDF实际上传、查询和报告导出；300份均EXTRACTED，300份商品行数正确。
2. 5,816项已覆盖核心字段值核对、300项自身单据编号核对、3,461项单位关联核对通过；数量/HS/金额真实冲突检查40项通过；干净/无害格式场景20项无误报检查通过。
3. 商品行页码和原文证据检查通过。SHP-00002仍保留三商品和880/880/888数量冲突；金额GBP5049.60、PL55箱、净463.60、毛503.43、1.073CBM。
4. 四行空HS原件SHP-00007和SHP-00097均保留四行，首行HS明确MISSING_IN_DOC，数量/金额未错列。其余空HS场景同样纳入完整集。
5. LINE_AMOUNT_MISMATCH及GROSS_BELOW_NET共20项原件检查通过；实际HTTP人工修正后旧警告清除、原始证据保留（8项）。
6. Python3.12.13/Paddle3.2.0/PaddleOCR3.7.0/PaddleX3.7.2默认配置，两组6份扫描原件实际新推理、真实HTTP均完成，未禁用oneDNN、未使用外部LLM或保存输出替代。
   T恤三份主体、独立编号、商品CT-2408、数量500正确；PI/CI单价2.80、总额/行金额1400 USD；PL商品行包装数20、净150、毛170、体积1.68正确，票/行金额NOT_IN_DOC，未生成USD500或0。
   包装和重量位于商品行，票级字段NOT_IN_DOC；没有验证票级自动汇总。PL原文PKGS未印CARTON，接口默认单位CARTON另列待确认。
7. 两组扫描品名均保留NOT_CHECKED。修改币种不会清除品名不确定状态，连做两次修正后仍可下载原始字节，金钱字段币种同步更新（11项）。
8. 23份EDI均真实上传得到UNSUPPORTED/FAILED；PDF+EDI为PARTIAL，原件下载逐字节相同。这是失败语义/来源能力验证，不能计为EDI解析支持或坏报文语法验证。
9. 完成任务、派生任务、部分成功任务重启后完整结果仍可读取，派生原件下载保持字节一致；JSON缺数量仍明确MISSING_IN_DOC/MISSING_IN_SOME；幂等和旧哈希409检查通过。
10. 当前135份实际公开返回通过固定版本Schema及引用/计数一致性校验。26项相关现有回归中25通过、Windows HTTP项跳过1项；真实HTTP另有独立覆盖。

确认的缺口及定位
A. 42票、126份原件的destination_country为NORMALIZE_FAILED，涉及Singapore, Singapore / Sydney, Australia / Melbourne, Australia。
   原文字段读到，失败在归一化。COUNTRY_GLOSSARY缺少AU/AUSTRALIA和SG/SINGAPORE，而CODE_TO_NAME及请求目的国允许AU/SG。
   这是当前仍有的覆盖缺口，未认定为本次提交新引入。请求里AU/SG仍保存；原件目的国核验未完成。
B. 一次真实处理中任务中断后，重启正确给FAILED/TASK_INTERRUPTED，但documents仍只有首文件且process_status=PARSING；三份已提交原件仅第一份在服务器落盘，另外两份下载404。
   main先读取全部上传为内存bytes；runner在逐文件解析循环内才落盘，重启丢失未轮到的文件；recover_interrupted只改任务终态，不收尾逐文件状态。
   问题位于接收后的持久化与处理中断收尾，不能表示用户未提供原件。未验证自动续跑，也未承诺自动续跑。
C. T恤PL原文列名PKGS、裸数20，接口packages.unit=CARTON、status=EXTRACTED。当前to_measure对裸数使用字段默认单位；独立人工金标保留unit=null。
   数值已正确；默认单位是否业务允许需C/F明确，不能宣布原件证明20箱。应区别原件单位、契约默认单位和推断单位。

核对口径和环境边界
- 文本描述直接比较normalized_value有753处差异；核对raw_value后753项业务描述均完整。差异由中英词表归一及保留同格显式SKU标签产生；不是753处确认漏读/错行。原始严格对照保留，未修改金标；统一规范化金标口径前不据该字符串差异计准确率。
- 另有10票买方地址差异未被覆盖，代码尚无地址提取/比较；这是已知能力边界，不混作此次回归失败。PI仍OTHER，必填语义待C/D确认。
- Python3.13/Paddle3.3.1默认配置6份扫描原件均遇到oneDNN ConvertPirAttribute2RuntimeAttribute错误。关闭oneDNN的独立TCP尝试连接中断、TestClient尝试300秒未获终态；均不计解析通过，亦不据此断言Linux生产崩溃。
- 后续按仓库推荐Python3.12/Paddle3.2默认配置的实际OCR成功，不抹去前述环境失败记录。模型版本/默认选择不同，不能合并成一个运行环境的成功率。
- 目的国法律适用、正式证书本体和HS官方归类、浏览器呈现、线上部署/重启、跨版式泛化尚未验收。单一合成模板100票不是生产准确率；处理COMPLETED、0冲突、Schema/单元测试通过均不构成整体验收。
- #43的B1–B6私有反例未取得，本轮实际原件/修正检查不能替代这六项按原反例验收。没有自行合并#39，多商品关系迁移未组合验收。

复现：见复现方法.txt。输入、请求、完整返回、报告、OCR原始输出、单位/行数/冲突检查、失败环境和中断恢复记录均保留；不含模型、数据库或凭据。
'''
(root/'复验记录.txt').write_text(report,encoding='utf-8')
copy(root/'复验记录.txt',packet/'复验记录.txt')
repro='''固定检出仓库PR37提交 fca14f56910333c4bac8c72cfd6428ffe2fb6f2a，不要用漂移分支代替。
安装该版本backend/requirements.txt。扫描新推理环境为Python3.12.13、paddlepaddle==3.2.0、paddleocr[doc-parser]==3.7.0、setuptools<82；完整版本锁见requirements-py312-ocr.lock.txt。
按固定源码backend/README.md安装PaddleCPU依赖；从仓库根npm ci用于公开输出校验。

在此证据包根目录执行（把<repo>换为固定源码路径）：
python -X utf8 review_latest.py --repo <repo> --dataset inputs/dataset --edi inputs/edi --out rerun-digital
python -X utf8 review_latest.py --repo <repo> --dataset inputs/dataset --edi inputs/edi --mode ocr --out rerun-ocr --ocr-cache <本机Paddle缓存目录>
node <repo>/backend/tools/validate_outputs.mjs <rerun-digital/public绝对路径>
node <repo>/backend/tools/validate_outputs.mjs <rerun-ocr/public绝对路径>

驱动固定SHA，另启127.0.0.1服务和独立SQLite/上传路径，finally中停止服务。OCR仅在--mode ocr时开启，保存原始模型输出但不改预测。金标在预测结束后读取，不传入应用。
返回码1可能表示保留下来的金标文本口径差异，不能只凭返回码判业务实错；核对summary/field-checks及复验记录。主驱动尚未纳入所有补充口径；补充对照脚本已随包保留。
analyze_originals.py、restart_interrupted.py、review_stored_workflow.py、prepare_delivery.py的本轮路径仍在常量中；跨机复跑需按包根及固定源码/数据位置调整，不能修改业务源码或原件。
中断恢复脚本需要新的实际中断任务数据库，不能以包内before/after保存结果替代新的重启操作。

输入范围：300文本PDF、3扫描PNG、3T恤原始PDF、23EDI、2项目JSON，共331份不同原始文件；保留原数据全量金标/元数据。未打包其余模拟扫描变体；不是360份原件全量包。
包内不含原运行SQLite、模型、缓存、环境凭据或生产日志。公开完整响应和报告见evidence，MANIFEST.sha256核对每个包内成员。
'''
(root/'复现方法.txt').write_text(repro,encoding='utf-8');copy(root/'复现方法.txt',packet/'复现方法.txt')
verification=[]
for stage in ['digital','ocr-default','ocr-py312-default']:
    for entry in json.loads((root/stage/'input-manifest.json').read_text(encoding='utf-8')):
        path=Path(entry['path']);actual=hashlib.sha256(path.read_bytes()).hexdigest()
        verification.append({'case':entry['case'],'path':entry['path'],'original_sha256':entry['sha256'],'after_sha256':actual,'unchanged':actual==entry['sha256']})
assert all(v['unchanged'] for v in verification)
(root/'originals-after-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
copy(root/'originals-after-verification.json',packet/'originals-after-verification.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==pin
assert not subprocess.check_output(['git','status','--short','--untracked-files=no'],cwd=source,text=True).strip()
checksums=[]
for path in sorted(packet.rglob('*')):
    if path.is_file() and path.name!='MANIFEST.sha256':
        checksums.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+path.relative_to(packet).as_posix())
(packet/'MANIFEST.sha256').write_text('\n'.join(checksums)+'\n',encoding='utf-8')
archive=root/'review37-fca14f5-independent.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in sorted(packet.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(packet).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for line in z.read('MANIFEST.sha256').decode('utf-8').splitlines():
        digest,name=line.split('  ',1);assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(root/(archive.name+'.sha256')).write_text(sha+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'source_commit':pin,'schema_results':len(validation_sources),'original_upload_records_rehashed':len(verification),
                  'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha,'manifest_entries':len(checksums)},ensure_ascii=False))
