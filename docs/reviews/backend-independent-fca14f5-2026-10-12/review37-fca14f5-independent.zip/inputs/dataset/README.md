# 单证合成数据集 v2：Hackathon 契约版

参考仓库 https://github.com/ycyc0421/Hackathon 的 main 提交 `30074b5c35ce378819f667d7bc515ac0fab3e7b2`。以 `docs/schema/check-task.schema.json` 为唯一对外格式依据；未修改原有字段枚举或放宽 schema。后端内部存在 `line_items`/行组结构，仓库的 `frontend_view.py` 将其展开成冻结的对外格式；本包直接输出该对外格式。

## 文件组织
- `backend/samples/SHP-xxxxx/`：100 票的输入单证，300份数字PDF、30张模拟扫描PNG、30份图片型PDF。原PDF和图像内容与v1一致。
- `docs/fixtures/raw/`：360份单文件抽取预期JSON，严格对应 Schema 的 `$defs.Extraction`，顶层只有 `file_id/doc_type/parse_method/fields`。
- `docs/fixtures/result/`：100份完整预期 `CheckTask` JSON，每票对应三个数字PDF。形式发票、商业发票、装箱单全部关联进同一票。
- `docs/schema/`：仓库原有CheckTask/Evaluation Schema和原validate.mjs。
- `dataset_manifest.csv`：输入文件、抽取预期JSON、同票关联、数据划分和场景分类。扫描图片与图片型PDF是同一内容的派生输入，不是额外货票。
- `evaluation_only/gold.jsonl`：异常注入真值、正确值与错误值，属于评测方资料，不是前端接口返回。
- `evaluation_only/rule_fixtures.json`：明确标注TEST_ONLY的证书引用测试规则。
- `evaluation_only/evaluation-not-run.json`：正式模型评测尚未运行，按Evaluation Schema返回NOT_RUN，不填写虚构准确率。
- `validation_report.json`：本批Schema和引用、自洽校验结果。
- `input_sha256.json`：360份输入文件的SHA-256。

本包内 `raw` 和 `result` 是**程序生成的预期金标/接口样例**，不是运行仓库后端得到的输出；`COMPLETED` 表示该合成接口样例完整，不声称模型处理已完成。任务中的时间用于标识合成批次，不用于性能统计。对外输出结构不额外添加合成标识字段；其来源写在 `input.notes`、本说明和独立 `dataset_provenance.json` 中。

## 主要格式变化
1. 原 `observed_fields` 对象改为 `fields[]`。每字段具有 `field_key,label,raw_text,raw_value,normalized_value,unit,confidence,status`。
2. `net_kg/gross_kg/cbm/sku` 分别改为 `net_weight/gross_weight/volume/item_code`；行金额是`amount`，整票金额是`total_amount`。
3. `packages`=包装箱数，`quantity`=商品件数，分别使用`CARTON`与`PCS`，不混用。
4. 多商品使用顶层`items[]`与各字段`item_id`；原单据行号保留为`line_no`，但不作为跨文件商品身份。合成行按唯一SKU关联。
5. 缺值使用`null`，不以空字符串充当缺失；严格区分`NOT_IN_DOC/MISSING_IN_DOC/NOT_CHECKED`。
6. 所有`confidence=null`，没有伪造OCR可信度。数字PDF的`parse_method=TEXT_LAYER`表示证据位置来源；扫描变体`parse_method=null`，因为未运行OCR。
7. 原坐标 `[x0,y0,x1,y1]`（PDF点）改为`[x,y,width,height]`、`bbox_unit=RELATIVE`；扫描变体不沿用父PDF坐标，`bbox=null`。
8. 比对`canonical_value`始终为`null`，正确值只保存在独立评测真值中。
9. 三种文件中的Date仅证明签发日期，用扩展键`issue_date`；不冒充装运日期，`shipment_date`为`NOT_IN_DOC`。
10. 采购订单PO用`purchase_order_no`，不冒充合同号`contract_no`。invoice_no为三份文件互引的CI编号，PI编号另外记在`proforma_invoice_no`。

Schema允许任意snake_case字段键，因此`consignee_address/shipper_phone/...`等扩展字段无需修改Schema。核心字段与仓库命名一致。金额是数值，币种通过`currency`字段及金额字段`unit`关联，以Schema为准，不用对象型金额。

## 类型与字段适用性
当前Schema没有PROFORMA_INVOICE，所以形式发票映射为`OTHER`；不能伪装成商业发票或提单。若团队之后正式扩展枚举，应重新转换，而不是单方面修改本包Schema。

只标注实际印在PDF上的字段。发票没有重量栏，重量为NOT_IN_DOC；装箱单没有HS栏，HS为NOT_IN_DOC。当前装箱单模板确实打印了币种，因此可以抽取币种，即使该字段不在通用最低要求中。

“缺少HS”场景表示商业发票已有名为HS CODE的列但对应单元格为空，按本模板预期标记MISSING_IN_DOC；并不是声称所有商业发票都依法必须填写HS。最低通用规则仍把商业发票HS列为可选。

相同格式金标可以直接作为契约示例加载到前端，但后端上传接口接收的是PDF/图片的multipart文件，而不是这些结果JSON。不要把金标作为模型输入。完整任务预期只涵盖数字PDF；扫描预期仅提供字段值，不提供OCR运行结果或虚构成功率。

## 场景与验证解释
10种场景各10票：语义一致、数量差异、买方地址差异、HS差异、行金额算错、毛重低于净重、HS空值、测试证书引用缺失、无害格式变化、多处错误。

原一个“异常注入”可能触发多个`comparisons`和一个`risk`；例如行金额错可同时造成行金额与整票总额不一致。`gold.jsonl`的expected_issue_count是注入条数，不是summary.conflict_count。后者严格按接口comparisons数组计算。

签发日期不同不作为冲突；大小写、电话分隔符、HS点号归一后不会误报。单据内部金额和重量逻辑错误放入`risks(type=OTHER)`，不虚构第二份来源来制造CONFLICT。

每票明确提供RULE_UNCOVERED信息提示：真实目的国规则未核实。证书引用缺失使用 `FIXTURE-XX-COO`、标注TEST_ONLY；不表示目的国普遍要求原产地证，也不证明证书本体不存在。HS为六位示意候选，不是官方归类金标。

## 校验与继续生成
Python 3.10+：
```bash
pip install -r requirements.txt
python validate.py
python build_dataset.py --count 1000 --seed 20261012 --out ../trade_documents_v3
```
生成器先在临时目录产生底层业务数据，再转换为同一对外契约并校验；输出目录内没有旧式observed_documents/labels JSON。

`validate.py`校验360份Extraction、100份CheckTask和1份Evaluation，另检查summary、引用关系、item_id、CONFLICT真实不同值、MATCH一致值、坐标范围与同票数据划分。

包内保留仓库`docs/schema/validate.mjs`；它的结构和summary检查可直接用于raw/result。运行时需在本包根目录安装ajv：`npm install ajv`，再`node docs/schema/validate.mjs`。本次实际执行的是Python Draft202012Validator加跨字段检查，未冒称执行npm脚本。

## 数据边界
沿用v1的100票模拟业务：公司和联系人虚构，邮箱使用`.example`保留域名。街道门牌随机、城市省州港口匹配，邮编为城市级示意，未验证真实地址或电话。商品只有6类，每票1-4类，单一版式；大规模扩量不等于跨版式泛化。

缺少提单、报关单、EDI与非英文单据，不声称覆盖全部赛题。模拟扫描不是实际扫描数据。原PDF已作版面检查，本次仅改变JSON/目录，不重绘PDF。
