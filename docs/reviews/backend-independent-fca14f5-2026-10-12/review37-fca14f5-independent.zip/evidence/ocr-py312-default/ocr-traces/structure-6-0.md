# PROFORMA INVOICE 

Document No.: PI-20260830-08300186Date: 2026-08-30


<div style="text-align: center;"><html><body><table border="1"><tbody><tr><td colspan="3">SELLER / EXPORTER Ningbo Qihang Export Co., Ltd. No. 168, Haitian North Road, Jiangbei District, Ningbo, Zhejiang, China Email: sales@qihangexport.example Tel:+86 574 8700 1234</td><td colspan="3">BUYER/ IMPORTER Global Fashion Inc. 1234 Broadway, Suite 500, New York, NY 10001, United States Email: purchasing@globalfashion.example Tel: +1 212 555 7890</td></tr><tr><td colspan="2">INCOTERM</td><td>FOBNingbo</td><td>PAYMENT TERMS</td><td>T/T 30% Deposit, 70% Before Shipment</td><td></td></tr><tr><td colspan="2">PORT OF LOADING</td><td colspan="2">Ningbo, China</td><td>PORT OF DES TINATION</td><td>New York, USA</td></tr><tr><td colspan="2">SHIPPINGMARK</td><td colspan="2">GLOBAL FASHION / NEW YORK / C.NO. 1-20</td><td>COUNTRY OF ORIGIN</td><td>China</td></tr><tr><td colspan="2">VESSEL / FLIGHT</td><td colspan="2">To be advised</td><td>CURRENCY</td><td colspan="2">USD</td></tr><tr><td colspan="2"></td><td colspan="5"></td></tr><tr><td>NO.</td><td colspan="2">DESCRIPTION OF GOODS</td><td>HS CODE</td><td>QUANTITY</td><td>UNIT PRICE</td><td>AMOUNT (USD)</td></tr><tr><td>1</td><td colspan="2">100% Cotton T-shirt, unisex, assorted colors SKU: CT-2408</td><td>6109.10</td><td>500 PCS</td><td>$2.80</td><td>$1,400.00</td></tr><tr><td colspan="7"></td></tr></tbody></table></body></html></div>


TOTAL AMOUNT INWORDS:

ONE THOUSAND FOUR HUNDRED AND OO/1OO USD ONLY 

BANKDETAILS:

Bank of China Ningbo Branch·A/C 6222 0000 0000 0000·SWIFT BKCHCNBJ92A 

NOTES:

Goods are packed for export and free from wood packaging materials.



Authorized Signature 