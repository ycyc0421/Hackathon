## PACKINGLIST 

Document No.: PL-20260830-08300186Date: 2026-08-30


<div style="text-align: center;"><html><body><table border="1"><tbody><tr><td colspan="4">SELLER / EXPORTER Ningbo Qihang Export Co., Ltd. No. 168, Haitian North Road, Jiangbei District, Ningbo, Zhejiang, China Email: sales@qihangexport.example Tel:+86 574 8700 1234</td><td colspan="4">BUYER / IMPORTER Global Fashion Inc. 1234 Broadway, Suite 500, New York, NY 10001, United States Email: purchasing@globalfashion.example Tel:+1 212 555 7890</td></tr><tr><td colspan="2"></td><td colspan="3"></td><td colspan="3"></td></tr><tr><td colspan="2">INCOTERM PORT OF LOADING</td><td colspan="3">FOBNingbo Ningbo, China</td><td colspan="3">PAYMENT TERMS</td></tr><tr><td colspan="2">SHIPPING MARK</td><td colspan="2">GLOBAL FASHION / NEW YORK / C.NO. 1-20</td><td colspan="2">COUNTRY OF ORIGIN</td><td colspan="2">China</td></tr><tr><td colspan="2"></td><td colspan="3"></td><td colspan="3"></td></tr><tr><td>VESSEL / FLIGHT</td><td>To be advised</td><td>CURRENCY</td><td colspan="2">USD</td><td>DESCRIP TIONOF GOODS</td><td>SKU</td><td>QTY</td></tr><tr><td>NO. 1</td><td>NETKG 150.00</td><td>GROSS KG 170.00</td><td colspan="2">100% Cotton T-shirt, unisex, assorted colors</td><td>CT-2408</td><td>500 PCS</td><td>20</td></tr><tr><td colspan="3">TOTAL</td><td>500</td><td>170.00</td><td>1.680</td><td>20</td><td>150.00</td></tr></tbody></table></body></html></div>


PACKING DECLARATION: The above goods are packed for export. Measurements and weights are declared by the exporter.

NOTES:

Goods are packed for export and free from wood packaging materials.



Authorized Signature 