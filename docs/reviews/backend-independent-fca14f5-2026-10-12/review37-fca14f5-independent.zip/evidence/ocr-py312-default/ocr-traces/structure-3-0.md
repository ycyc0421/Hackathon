# PROFORMA INVOICE 

Document No.:PI-00001Date: 2026-05-30

Shipment: SHP-00001|PO:PO-369981-1


<div style="text-align: center;"><html><body><table border="1"><tbody><tr><td colspan="3">SELLER/EXPORTER Harbor Industrial 0001 Co., Ltd. 358 River Road, Suie 8 Shanghai,Shanghai 200000,China Email:orders0001@harbor.example Tel:+8621 9052001|Alex Morgan</td><td colspan="3">BUYER/IMPORTER Aster Distribution 1001 Inc. 234 Union Street, Suite 68 Seattle,WA 98101,United States Email:orders1001@atlas.exampe Tel:+12061441590|Sam Chen</td></tr><tr><td colspan="3">INCOTERM FOB Shanghai</td><td colspan="3">PAYMENT TERMS T/T 100% before shipment</td></tr><tr><td colspan="3">PORT OF LOADING Shanghai, China</td><td colspan="3">DESTINATION Seattle, United States</td></tr><tr><td colspan="3">SHIPPING MARK ASTER/SHP-00001/C.NO.1-17</td><td colspan="3">ORIGIN China</td></tr><tr><td colspan="3">VESSEL / FLIGHT MV Meridian/V890</td><td colspan="3">CURRENCY USD</td></tr><tr><td colspan="6"></td></tr><tr><td>NO.</td><td>DESCRIPTION/SKU</td><td>HS CODE</td><td>QUANTITY</td><td>UNIT PRICE</td><td>AMOUNT</td></tr><tr><td>1</td><td>Cotton terry bathtowel,assorted colors/SKU: SKU-0001-1</td><td>630260</td><td>204 PCS</td><td>4.52</td><td>922.08</td></tr></tbody></table></body></html></div>


TOTAL AMOUNT (USD): 922.08

REFERENCES:CICI-00001|PI PI-00001|PLPL-00001

NOTES: Goods packed in corrugated cartons; no wooden packaging.

Attached certificate references:COO-SHP-00001

BANKDETAILS:Synthetic Test Bank/reference TEST-37084419(non-operational)

Authorized Signature 