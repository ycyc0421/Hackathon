# PACKING LIST 

Document No.:PL-00001Date: 2026-06-07

Shipment: SHP-00001|PO:PO-369981-1


<div style="text-align: center;"><html><body><table border="1"><tr><td>SELLER/EXPORTER Harbor Industrial 0001 Co., Ltd. 358 River Road, Suite 8 Shanghai, Shanghai 200000, China Email:orders0001@harbor.example Tel:+86 21 9052001|Alex Morgan</td><td>BUYER/IMPORTER Aster Distribution 1001 Inc. 234 Union Street, Suite 68 Seattle, WA 98101, United States Email:orders1001@atlas.example Tel:+1 206 1441590|Sam Chen</td></tr><tr><td>INCOTERM FOB Shanghai</td><td>PAYMENT TERMS T/T 100% before shipment</td></tr><tr><td>PORT OF LOADING Shanghai, China</td><td>DESTINATION Seattle, United States</td></tr><tr><td>SHIPPING MARK ASTER/SHP-00001/C.NO.1-17</td><td>ORIGIN China</td></tr><tr><td>VESSEL/FLIGHT MV Meridian/ V890</td><td>CURRENCY USD</td></tr></table></body></html></div>



<div style="text-align: center;"><html><body><table border="1"><tr><td>NO.</td><td>DESCRIPTION /SKU</td><td>QTY</td><td>PKGS</td><td>NET KG</td><td>GROSS KG</td><td>CBM</td></tr><tr><td>1</td><td>Cotton terry bath towel,assorted colors/SKU: SKU-0001-1</td><td>204 PCS</td><td>17</td><td>97.92</td><td>108.91</td><td>0.640</td></tr></table></body></html></div>


TOTAL:204PCS|17CARTONS|NET97.92KG|GROSS108.91KG|0.640CBM 

REFERENCES:CICI-00001|PI PI-00001|PLPL-00001

NOTES: Goods packed in corrugated cartons; no wooden packaging.

Attached certificate references:COO-SHP-00001

Authorized Signature 