"""Run untouched package inputs through a locally isolated candidate backend."""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")
cli = argparse.ArgumentParser()
cli.add_argument("--repo", type=Path, required=True)
cli.add_argument("--dataset", type=Path, required=True)
cli.add_argument("--out", type=Path, required=True)
cli.add_argument("--groups", default="11,12,13,14,15,16,17,18,19,20,31,91")
cli.add_argument("--kind", choices=["digital", "scan_png", "scan_pdf"], default="digital")
cli.add_argument("--ocr", action="store_true")
cli.add_argument("--disable-mkldnn", action="store_true", help="Windows-only diagnostic runtime override, not a source change")
cli.add_argument("--max-wait", type=int, default=300)
cli.add_argument("--ocr-cache", type=Path, help="Optional PaddleX model cache directory")
args = cli.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
os.environ["PADDLE_OCR_ENABLED"] = "1" if args.ocr else "0"
os.environ["LLM_BASE_URL"] = ""
os.environ["LLM_API_KEY"] = ""
os.environ["LLM_MODEL"] = ""
os.environ["TASK_DB_PATH"] = str(args.out / "runtime/tasks.sqlite3")
if args.ocr_cache:
    os.environ["PADDLE_PDX_CACHE_HOME"] = str(args.ocr_cache.resolve())
os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
sys.path.insert(0, str(args.repo / "backend"))
from app import config
config.DATA_DIR = args.out / "runtime"
config.UPLOAD_DIR = config.DATA_DIR / "uploads"
config.TASK_DIR = config.DATA_DIR / "tasks"
from app import main
from app.pipeline import runner
from fastapi.testclient import TestClient
for name in ["httpx", "httpx2", "backend.api"]:
    logging.getLogger(name).setLevel(logging.WARNING)

if args.disable_mkldnn:
    assert args.ocr
    from app.pipeline import paddle_reader
    import threading
    class TracedModel:
        def __init__(self, model, name):
            self.model, self.name, self.count = model, name, 0
        def predict(self, **kwargs):
            outputs = list(self.model.predict(**kwargs))
            self.count += 1
            trace = args.out / "ocr-traces"
            trace.mkdir(exist_ok=True)
            for index, output in enumerate(outputs):
                stem = f"{self.name}-{self.count}-{index}"
                try:
                    output.save_to_json(str(trace / (stem + '.json')))
                    if self.name == 'ordinary':
                        (trace / (stem + '.txt')).write_bytes(('\n'.join(map(str, output.json['res']['rec_texts']))).encode('utf-8'))
                    else:
                        (trace / (stem + '.md')).write_bytes(output.markdown['markdown_texts'].encode('utf-8'))
                except Exception as error:
                    (trace / (stem + '.trace-error.txt')).write_bytes(str(error).encode('utf-8'))
            return outputs
    def get_ordinary():
        with paddle_reader._model_lock:
            if paddle_reader._ocr is None:
                from paddleocr import PaddleOCR
                paddle_reader._ocr = TracedModel(PaddleOCR(cpu_threads=4, enable_mkldnn=False,
                    use_doc_orientation_classify=False, use_doc_unwarping=False, use_textline_orientation=False), 'ordinary')
            return paddle_reader._ocr
    def get_structure():
        with paddle_reader._model_lock:
            if paddle_reader._structure is None:
                from paddleocr import PPStructureV3
                paddle_reader._structure = TracedModel(PPStructureV3(cpu_threads=4, enable_mkldnn=False,
                    use_doc_orientation_classify=False, use_doc_unwarping=False, use_formula_recognition=False, use_seal_recognition=False), 'structure')
            return paddle_reader._structure
    paddle_reader._get_ocr = get_ordinary
    paddle_reader._get_structure = get_structure

manifest = list(csv.DictReader((args.dataset / "dataset_manifest.csv").open(encoding="utf-8-sig")))
input_hashes = json.loads((args.dataset / "input_sha256.json").read_text(encoding="utf-8"))
groups = [f"SHP-{int(number):05d}" for number in args.groups.split(",")]
commit = subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", "HEAD"], text=True).strip()

def save(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))

def same(actual, expected, key):
    if isinstance(expected, (int, float)):
        return isinstance(actual, (int, float)) and math.isclose(actual, expected, abs_tol=0.000001, rel_tol=1e-9)
    if key == "hs_code":
        return str(actual).replace(".", "") == str(expected).replace(".", "")
    if key in {"shipper", "consignee"}:
        import re
        clean = lambda value: re.sub(r"[^\w]", "", str(value)).casefold()
        return clean(actual) == clean(expected)
    return str(actual).upper() == str(expected).upper()

predictions = []
with TestClient(main.app) as client:
    for group in groups:
        members = [row for row in manifest if row["shipment_group_id"] == group and
                   (row["sample_kind"] == "synthetic" if args.kind == "digital" else row["document_id"].endswith("_" + args.kind))]
        members.sort(key=lambda row: Path(row["local_path"]).name)
        assert len(members) == 3, (group, args.kind, len(members))
        # Only declared shipment input is used here; expected field values are read after prediction.
        request_meta = json.loads((args.dataset / "docs/fixtures/result" / f"{group}.json").read_text(encoding="utf-8"))["input"]
        data = {key: request_meta[key] for key in ["destination_country", "destination_country_name"] if request_meta.get(key)}
        originals = []
        for member in members:
            path = args.dataset / member["local_path"]
            payload = path.read_bytes()
            digest = hashlib.sha256(payload).hexdigest()
            reference = input_hashes.get(member["local_path"]) if isinstance(input_hashes, dict) else None
            if isinstance(reference, dict):
                reference = reference.get("sha256")
            if reference:
                assert digest == reference, path.name
            originals.append({"name": path.name, "source_path": member["local_path"], "sha256": digest,
                              "fixture_path": member["extraction_path"], "document_id": member["document_id"]})
        files = [("files", (Path(member["local_path"]).name, (args.dataset / member["local_path"]).read_bytes(),
                              "application/pdf" if member["file_type"] == "PDF" else "image/png")) for member in members]
        started = time.monotonic()
        response = client.post("/api/v1/checks", data=data, files=files)
        assert response.status_code == 200, (group, response.status_code, response.text)
        task = response.json()
        deadline = started + (args.max_wait if args.ocr else 30)
        while task["status"] in {"PENDING", "PROCESSING"} and time.monotonic() < deadline:
            time.sleep(0.2)
            task = client.get(f"/api/v1/checks/{task['task_id']}").json()
        assert task["status"] not in {"PENDING", "PROCESSING"}, f"Timed out: {group}"
        raw_task = main.store.get(task["task_id"])
        record = {"group": group, "kind": args.kind, "category": members[0]["category"], "seconds": round(time.monotonic() - started, 3),
                  "request": data, "originals": originals, "api_task": task, "internal_task": raw_task}
        save(args.out / "predictions" / f"{group}.json", record)
        predictions.append(record)
        print(json.dumps({"group": group, "category": record["category"], "status": task["status"],
                          "items": len(task.get("items", [])), "summary": task.get("summary"), "seconds": record["seconds"]}), flush=True)

# Evaluation is separate from execution; gold values never enter the extraction pipeline.
gold = {obj["shipment_group_id"]: obj for obj in map(json.loads, (args.dataset / "evaluation_only/gold.jsonl").read_text(encoding="utf-8").splitlines())}
DOC_KEYS = {"document_no", "total_amount", "net_weight", "gross_weight", "packages", "volume", "currency", "shipper", "consignee"}
ROW_KEYS = {"item_code", "quantity", "hs_code", "packages", "net_weight", "gross_weight", "volume", "unit_price", "amount"}
evaluations = []
for record in predictions:
    task = record["api_task"]
    docs = {doc["file_name"]: doc for doc in task["documents"]}
    extractions = {ext["file_id"]: ext for ext in task.get("extractions", [])}
    checks, missing_pages, row_counts = [], [], []
    for original in record["originals"]:
        expected = json.loads((args.dataset / original["fixture_path"]).read_text(encoding="utf-8"))
        doc = docs[original["name"]]
        extraction = extractions.get(doc["file_id"], {"fields": []})
        actual_rows = defaultdict(dict)
        actual_doc = {}
        for field in extraction["fields"]:
            if field.get("item_id"):
                actual_rows[field["line_no"]][field["field_key"]] = field
                if field.get("normalized_value") is not None and field.get("page") is None and doc.get("page_count") == 1:
                    missing_pages.append({"file": original["name"], "line_no": field["line_no"], "key": field["field_key"]})
            else:
                actual_doc[field["field_key"]] = field
        expected_rows = {field["line_no"] for field in expected["fields"] if field.get("item_id")}
        row_counts.append({"file": original["name"], "expected": len(expected_rows), "actual": len(actual_rows), "process_status": doc["process_status"]})
        for field in expected["fields"]:
            is_row = bool(field.get("item_id"))
            if field["field_key"] not in (ROW_KEYS if is_row else DOC_KEYS):
                continue
            if field.get("normalized_value") is None:
                continue
            got = (actual_rows.get(field["line_no"], {}) if is_row else actual_doc).get(field["field_key"])
            checks.append({"file": original["name"], "line_no": field.get("line_no"), "key": field["field_key"],
                           "expected": field["normalized_value"], "actual": got.get("normalized_value") if got else None,
                           "actual_status": got.get("status") if got else "NO_FIELD", "actual_unit": got.get("unit") if got else None,
                           "expected_unit": field.get("unit"),
                           "ok": got is not None and same(got.get("normalized_value"), field["normalized_value"], field["field_key"])})
    observed_conflicts = [{"key": comp["field_key"], "item_id": comp.get("item_id"), "values": comp["values"]}
                          for comp in task.get("comparisons", []) if comp["status"] == "CONFLICT"]
    evaluation = {"group": record["group"], "kind": record["kind"], "category": record["category"], "task_status": task["status"],
                  "row_counts": row_counts, "checks": checks, "failed_checks": [check for check in checks if not check["ok"]],
                  "single_page_row_fields_missing_page": missing_pages, "gold_injected_issues": gold[record["group"]]["issues"],
                  "observed_conflicts": observed_conflicts, "error_codes": [error["code"] for error in task.get("errors", [])],
                  "observed_risks": task.get("risks", [])}
    evaluations.append(evaluation)
    save(args.out / "evaluations" / f"{record['group']}.json", evaluation)
summary = {"commit": commit, "mode": "local HTTP TestClient plus real pipeline and isolated SQLite", "ocr_enabled": args.ocr,
           "diagnostic_runtime_override": "enable_mkldnn=False in local OCR constructors" if args.disable_mkldnn else None,
           "external_llm_enabled": False, "input_kind": args.kind, "groups": len(evaluations), "documents": 3 * len(evaluations),
           "task_statuses": dict(Counter(result["task_status"] for result in evaluations)),
           "field_checks": sum(len(result["checks"]) for result in evaluations),
           "failed_field_checks": sum(len(result["failed_checks"]) for result in evaluations),
           "groups_with_failed_field_checks": [result["group"] for result in evaluations if result["failed_checks"]],
           "row_count_mismatches": [dict(group=result["group"], **row) for result in evaluations for row in result["row_counts"] if row["expected"] != row["actual"]],
           "single_page_row_fields_missing_page": sum(len(result["single_page_row_fields_missing_page"]) for result in evaluations),
           "note": "Synthetic one-template regression; gold is generated expectation, not a model output or legal truth. Certificate TEST_ONLY rule is not loaded."}
save(args.out / "summary.json", summary)
save(args.out / "evaluations.json", evaluations)
print(json.dumps(summary, ensure_ascii=False), flush=True)
